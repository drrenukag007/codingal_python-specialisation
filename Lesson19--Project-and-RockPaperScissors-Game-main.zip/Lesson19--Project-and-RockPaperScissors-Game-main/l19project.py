import math

number = int(input("Enter a number: "))
sin = (math.sin(number))
cos = (math.cos(number))
tan = (math.tan(number))

print(("The sin of", number, "is"),sin)
print(("The cos of", number, "is"),cos)
print(("The tan of", number, "is"),tan)

