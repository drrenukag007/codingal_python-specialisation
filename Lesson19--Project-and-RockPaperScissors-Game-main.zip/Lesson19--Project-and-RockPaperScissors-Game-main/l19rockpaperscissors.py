import random
print("rock = 1")
print("scissors = 2")
print("paper = 3")

computerpoint =  0
playerpoint = 0
rock = 1
scissors = 2
paper = 3

for i in range(1,11):
    item = random.randint(1,3)
    useritem = int(input("Enter 1 (rock), 2 (scissors) or 3 (paper): "))
    if useritem == 1 and item == 1:
        print("This round is a draw, no one gains a point.")
        print("The computer selected",item, "and you selected",useritem)
        print("Your current score is", playerpoint)
        print("The computer's current score is", computerpoint)
    elif useritem == 1 and item == 2:
        print("You won this round! ")
        playerpoint +=1
        print("Your current score is", playerpoint)
        print("The computer's current score is", computerpoint)
        print("The computer selected",item, "and you selected",useritem)

    elif useritem == 1 and item == 3:
        print("The computer won this round.")
        computerpoint +=1
        print("Your current score is", playerpoint)
        print("The computer's current score is", computerpoint)
        print("The computer selected",item, "and you selected",useritem)

    elif useritem == 2 and item == 1:
        print("The computer won this round.")
        computerpoint +=1
        print("Your current score is", playerpoint)
        print("The computer's current score is", computerpoint)
        print("The computer selected",item, "and you selected",useritem)

    elif useritem == 2 and item == 2:
        print("This round is a draw, no one gains a point.")
        print("Your current score is", playerpoint)
        print("The computer's current score is", computerpoint)
        print("The computer selected",item, "and you selected",useritem)

    elif useritem == 2 and item == 3:
        print("You won this round!")
        playerpoint +=1
        print("Your current score is", playerpoint)
        print("The computer's current score is", computerpoint)
        print("The computer selected",item, "and you selected",useritem)

    elif useritem == 3 and item == 1:
        print("You won this round!")
        playerpoint +=1
        print("Your current score is", playerpoint)
        print("The computer's current score is", computerpoint)
        print("The computer selected",item, "and you selected",useritem)

    elif useritem == 3 and item == 2:
        print("The computer won this round.")
        computerpoint +=1
        print("Your current score is", playerpoint)
        print("The computer's current score is", computerpoint)
        print("The computer selected",item, "and you selected",useritem)

    elif useritem == 3 and item == 3:
        print("This round is a draw, no one gains a point.")
        print("Your current score is", playerpoint)
        print("The computer's current score is", computerpoint)
        print("The computer selected",item, "and you selected",useritem)

    
    print("       ")
if computerpoint > playerpoint:
    print("The computer won this game.")
    print("Your score is", playerpoint)
    print("The computer's score is", computerpoint)
elif playerpoint > computerpoint:
    print("You won this game!")
    print("Your score is", playerpoint)
    print("The computer's score is", computerpoint)
else:
    print("The scores are tied.")
    print("Your score is", playerpoint)
    print("The computer's score is", computerpoint)
        
        

