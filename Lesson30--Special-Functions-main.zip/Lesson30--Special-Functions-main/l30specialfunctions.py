class Myclass():
    #private variable
    __privatevar=12
    #private method/function
    def __privatemethod(self):
        print("I am inside my class")
        a=8
        b=7
        self.result=a+b
        print("The total is",self.result)

    def hello(self):
        print("Good Morning.")
        print("The private variable is", Myclass.__privatevar)

    def test(self):
        self.__privatemethod()

myra=Myclass()
myra.hello()
myra.test()

