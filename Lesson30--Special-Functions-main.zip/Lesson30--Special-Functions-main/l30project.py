class Reverse:
    def __init__(self, s=""):
        self.__s = s

    def set_string(self, new_string):
        self.__s = new_string

    def get_reversed(self):
        return self.__s[::-1]

user_input = input("Enter a word: ")

rev = Reverse()  
rev.set_string(user_input)  

print("The reversed word is", rev.get_reversed())
