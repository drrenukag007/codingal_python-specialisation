#With encapsulation
class Mobile():
    def __init__(self):
        self.__price=1000
        self.screen=6
        self.colour="rosegold"

    def display(self):
        print(self.__price)
        print(self.screen)
        print(self.colour)

    def changeprice(self,newprice):
        self.price=newprice

mob=Mobile()
mob.display()
mob.changeprice(500)
mob.display()