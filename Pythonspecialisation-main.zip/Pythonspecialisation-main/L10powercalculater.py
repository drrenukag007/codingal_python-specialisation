x=int(input("Which numbers power do you want to calculate?"))
y=int(input("To which do you want to raise it?"))

print(x**y)
