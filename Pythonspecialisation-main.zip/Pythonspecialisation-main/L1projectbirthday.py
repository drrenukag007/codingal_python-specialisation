bd1="Coley's-birthday-is-on-Jan_1st"
bd2="Sanfrick's-birthday-is-on-June_25"
bd3="Brian's-birthday-is-on-Sep_15"
bd4="Amy's-birthday-is-on-Nov_18"
bd5="Judy's-birthday-is-on-Dec_10"

print(bd1)
print(bd2)
print(bd3)
print(bd4)
print(bd5)
