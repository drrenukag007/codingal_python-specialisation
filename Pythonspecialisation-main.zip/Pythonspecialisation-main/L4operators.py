number1 =2
number2 =7

print(number1+number2)
print(number1-number2)
print(number1*number2)
print(number2/number1)



print(number2//number1)
print(number2%number1)
print(5**3)