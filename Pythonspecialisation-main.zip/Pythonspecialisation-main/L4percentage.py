english=int(input("How much you scored in english "))
maths=int(input("How much you scored in maths "))
science=int(input("How much you scored in science "))

sum=english + maths + science
answer=(sum/300)*100
print(answer)

avg=(sum/3)
print(avg)