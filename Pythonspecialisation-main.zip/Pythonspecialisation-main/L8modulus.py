x=int(input("Enter the first number"))
y=int(input("Enter the second number"))


result=x%y

if result==0:
    print("This number is divisible")
else:
    print("This number is not divisible")