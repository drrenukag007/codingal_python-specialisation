x=int(input("What is your age?"))
if x>=10:
    if x<15:
        print("The user is less than 20 years old ")
    if x>20:
        print("The user is more than 20 years old")
else:
    print("The age is not equal to 10")   