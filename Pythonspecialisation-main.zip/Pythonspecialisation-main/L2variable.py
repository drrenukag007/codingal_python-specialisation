car="bmw"
print (car)

number1 = 23478
number2 = 9764780

print (number1 + number2)
result= number2 - number1 
print (result)
 
multiply = number1 * number2
print(multiply)

quotient= number2 / number1
print (quotient)