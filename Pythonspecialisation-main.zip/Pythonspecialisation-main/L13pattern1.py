count=1

for i in range(1,11):
    print(i*'&')



while count<13:
    print(count*"&")
    count=count+1