score=0
score=score+10
print(score)

score+=10
print(score)