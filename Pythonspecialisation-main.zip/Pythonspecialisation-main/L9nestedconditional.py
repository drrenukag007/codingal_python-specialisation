x=int(input("Enter a number"))

if x>=0:
    if x==0:
        print("The number is zero")
    else:
        print("The number is positive")


else:
    print("The number is negative")