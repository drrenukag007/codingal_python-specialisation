number=2
while number<6:
    print("table of ",number)
    count=1
    while count<11:
        print(number*count)
        count=count+1
    number=number+1
    