number=6
while number<10:
    print("table of ",number)
    count=1
    while count<6:
        print(number*count)
        count=count+1
    number=number+1
    
