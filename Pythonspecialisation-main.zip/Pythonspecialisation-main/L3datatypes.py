car="mercedes"    
print("the data type of car is",type(car))
print(car)

number1= 345 
print("the data type of number one is",type(number1))
print(number1)

weight= 45.78
print("the data type of weight is",type(weight))
print(weight)

birds_fly=True
print("the data type of birds_fly is",type(birds_fly))
print(birds_fly)

number1_string=str(number1)
print("the converted data type",type(number1_string))
print(number1_string)

number1_float=float(number1)
print("the converted data type",type(number1_float))
print(number1_float)

