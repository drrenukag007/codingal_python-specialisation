alpha=input("Enter a character")
 
if type(alpha)=="str":
    print("It is an alphabet")
else:
    print("It is not an alphabet")    


