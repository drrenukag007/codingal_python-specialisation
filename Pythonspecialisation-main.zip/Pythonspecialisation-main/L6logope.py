a=15
b=18

if (a>b) and (b>a):
   print("the number is greater thsn the other")
else:
   print("the number is not greater than the other")

if (a>b) or (b>a):
   print("the number is greater thsn the other")
else:
   print("the number is not greater than the other")

if a!=b:
   print("the number is greater thsn the other")
else:
   print("the number is not greater than the other")