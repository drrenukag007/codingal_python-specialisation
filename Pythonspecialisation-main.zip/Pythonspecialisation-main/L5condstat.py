chocolates=input("Would you like a chcolate? y/n " )

if chocolates== "y":
   print("Ok so lets go to the store")
else: 
   print("Lets have something else than") 


   