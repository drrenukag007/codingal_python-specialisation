x=5
y=2

a=x
y=a

b=y
x=b


print(x)
print(y)