x=[1,2,3,4,5]
print(3 in x)
print(6 in x)

print(3 not in x)
print(6 not in x)