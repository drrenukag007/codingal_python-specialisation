#print 1 to 20
count=1
while count<21:   #until the value is less than 20
    print(count)

    count=count+1


#odd numbers

count=1
while count<21:   #until the value is less than 20
    print(count)

    count=count+2


#even numbers

count=2
while count<21:   #until the value is less than 20
    print(count)

    count=count+2




