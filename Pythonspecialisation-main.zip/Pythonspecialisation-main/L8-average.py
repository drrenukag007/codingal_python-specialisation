sadhiya=10
banusha=20
asra=30

sum=sadhiya+banusha+asra
avg=sum/3
print(avg)


