var="congratulations"
print(var.lower())

print(var.upper())