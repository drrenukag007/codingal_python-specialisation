#loop running infinity
#because the comdition is always true

count=10
while count>2:   #greater than two
    print("hello")
    count=count+1


    if count==25:
        print("The number is 25")     #if we want to stop the loop we break(keyword) it
        break
