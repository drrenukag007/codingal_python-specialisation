number1=int(input("What is the first number for which you need to find the sq.root? "))

print(number1**1/2)


number2=int(input("What is the second number for which you need to find the sq.root? "))

print(number2**1/2)


