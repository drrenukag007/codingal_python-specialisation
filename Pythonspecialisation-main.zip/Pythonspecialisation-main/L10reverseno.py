for i in range(10,0,-1):
    print(i)



for i in range(1,21,2):
    print(i)