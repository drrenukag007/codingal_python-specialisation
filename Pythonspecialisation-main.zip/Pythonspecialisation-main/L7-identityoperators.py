a=12
b=14
 
if (type(a) is int):
    print("It is integer")
else:
    print("It is not integer")

 
if (type(b) is int):
    print("It is integer")
else:
    print("It is not integer")


a="car"
 
if (type(a) is int):
    print("It is integer")
else:
    print("It is not integer")

a=12
 
if (type(a) is not int):
    print("It is not an integer")
else:
    print("It is integer")



