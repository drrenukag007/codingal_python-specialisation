print("Welcome to the Quiz")
Q1=input("What would you like to have for dinner? a-pizza,b-burger,c-steak,d-biryani,e-pulav")
if Q1=="a":
    print("Lets serve pizza foryou")
elif Q1=="b":
    print("Lets serve burger")
elif Q1=="c":
    print("Lets serve steak")
elif Q1=="d":
    print("Lets serve biryani")
elif Q1=="e":
    print("Lets serve pulav")
else:
    print("choose the correct option")


    

