x=4
y=8
z=6

result=x+y*3*(x+z)-y**3
print(result)