num=int(input("enter any decimal number."))
binary=bin(num)
print(binary)