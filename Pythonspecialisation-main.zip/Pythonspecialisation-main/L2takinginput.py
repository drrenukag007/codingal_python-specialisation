number1 = int(input("enter the first number"))
number2 = int(input("enter the second number"))

result = number1+number2
print (result)

print(type(number1))
print(type(number2))