number1=int(input("Enter a number" ))
if number1<0:
    print(number1,"is a negative number")
else:
    print(number1,"is a positive number")