x=int(input("How many numbers you want to add?"))
result=0

for i in range(1,x+1):
    result=result+i
    print(result)

