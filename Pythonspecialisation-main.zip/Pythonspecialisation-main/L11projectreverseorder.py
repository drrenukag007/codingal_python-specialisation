num=int(input("Enter a number between 1-100000"))
if num<10:
    print("It is a one digit number")
    
elif num<100:
    print("It is a two digit number")

elif num<1000:
    print("It is a three digit number")

elif num<10000:
    print("It is a four digit number")

elif num<100000:
    print("It is a five digit number")
          
