print ('my first coding class')


fruit ="apple"
fruit2 = 123

print(fruit)
print(fruit2)


