count=10
while count>2:   #less than two
    print("hello")
    count=count-1