firstname="Noor"
secondname="Afza"

result= firstname +" " + secondname
print(result.upper())

print(result.lower())

print(result[0:4])

print(result[0])

print(result[0:2])