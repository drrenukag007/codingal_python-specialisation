class Family():
    def __init__(self, name,facial_struc,height,age,relation):
        self.name=name
        self.facial_struc=facial_struc
        self.height=height
        self.age=age
        self.relation=relation
    
    def eating(self):
        print("lets have dinner together.")

object1=Family("Myra","round",5.11,14,"daughter")
object2=Family("Smriti","round", 5.2,32,"mother")

print(object1.name, object1.facial_struc, object1.age)
object2.eating()