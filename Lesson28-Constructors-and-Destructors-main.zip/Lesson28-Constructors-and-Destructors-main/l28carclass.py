class Car():
    def __init__(self, name, model, colour):
        self.name=name
        self.model=model
        self.colour=colour

    def ride(self):
        print("This car allows you to drive around the city.")

object1=Car("Tesla","Model X","black")
object2=Car("BMW", "Model 8","blue")

print(object1.name,object1.model,object1.colour)
object2.ride()