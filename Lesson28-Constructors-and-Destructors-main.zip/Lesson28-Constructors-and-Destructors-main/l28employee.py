class Employee():
    def __init__(self,name, height,age,qualification):
        self.name=name
        self.height=height
        self.age=age
        self.qualification=qualification
        print("The employee has entered the premises. The attendence is marked.")
    def __del__(self):
        print("The employee has exited the company premises.")
        
    def work(self):
        print("The employee works at the premise.")

employee1= Employee("Myra", 5.2,14,"Skilled")
employee2= Employee("Smriti",5.8,32, "Semi-Skilled")


        
        