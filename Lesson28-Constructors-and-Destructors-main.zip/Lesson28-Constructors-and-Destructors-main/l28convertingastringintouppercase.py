stringword = input("Enter a word: ")

print(stringword.upper())
