math = {"Myra", "Renuka", "Ravi", "Samaira", "Geeta", "Smriti", "Saurabh", "Raghav", "Layla", "Lucia"}
art = {"Myra", "Renuka", "Aadya", "Amina", "Lucia", "Babita", "Anju", "Gopal", "Ram"}

#Union of both items 
print(math.union(art))

#Intersection of both items
print(math.intersection(art))

#People who like math but not art
print(math.difference(art))

#People who like art but not math
print(art.difference(math))

#People who only like one thing, and not the other 
print(math.symmetric_difference(art))

#Type of code
print(type(math))