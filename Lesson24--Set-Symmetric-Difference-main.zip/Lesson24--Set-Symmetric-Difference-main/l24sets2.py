numbers1 = {1,2,3,4,5,6,7,8}
numbers2 = {8,9,10,2,4,11,12,18}

print(numbers1.union(numbers2))

print(numbers1.intersection(numbers2))

print(numbers1.difference(numbers2))

print(numbers1.symmetric_difference(numbers2))