book = {"Harry Potter": "J.K Rowling","Percy Jackson": "Rick Riordan","One of us is lying": "Karen M. McManus","Hunger Games": "Suzanne Collins","Good Girl Bad Blood": "Holly Jackson","A Good Girls Guide to Murder": "Holly Jackson","Five Survive": "Holly Jackson","Hero's of Olympus": "Rick Riordan","Diary of a Wimpy Kid": "Jeff Kinney","The Trials of Aleppo": "Rick Riordan"}

print("Welcome to the Library Management System")

while True:
    print("Option 1: View all the books")
    print("Option 2: Add a book")
    print("Option 3: Borrow a book")
    print("Option 4: Return a book")
    print("Option 5: Exit simulation")

    option = int(input("Which option would you like to pick? "))

    if option == 1:
        print("List of all books:")
        for i,j in book.items():
            print(i,j)
            print(        )
    elif option == 2:
        addingbook = input("Which book would you like to add? ")
        author = input("Who is the author of your book? ")
        book[addingbook] = author
        print("Your book has now been added to the library.")
        print(book)
    elif option == 3:
        print("Available books:")
        for i,j in book.items():
            print(i,j)
            borrowingbook = input("Which book would you like to borrow? ")
            del book[borrowingbook]
            print("You have successfully borrowed the book. ")
    elif option == 4:
        returningbook = input("Which book would you like to return? ")
        author = input("Who is the author of this book?")
        book[returningbook] = author
        print("You have successfully returned this book.")
        print(book)
    elif option == 5:
        print("Thank you for using the Library Management System.")
        break
    else:
        print("Please choose a valid option")
