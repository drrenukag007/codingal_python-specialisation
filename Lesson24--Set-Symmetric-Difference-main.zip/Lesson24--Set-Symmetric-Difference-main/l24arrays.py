import array as ar
numberarray = ar.array("i", [1,4,5,6,7,8])

print(numberarray)
print(type(numberarray))

#Counting a specific item in the array
count_num = numberarray.count(1)
print(count_num)

#Reversing the items

numberarray.reverse()
print(str(numberarray))