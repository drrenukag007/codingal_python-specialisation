num1 = int(input("Enter a number"))
num2 = int(input("Enter a number"))
print(type(num1))
ans1 = num1 + num2
ans2 = num1 - num2
ans3 = num1 * num2
ans4 = num1 / num2

print("The addition of these numbers is", ans1)
print("The subtraction of these numbers is", ans2)
print("The multiplication of these numbers is", ans3)
print("The division of these numbers is", ans4)

