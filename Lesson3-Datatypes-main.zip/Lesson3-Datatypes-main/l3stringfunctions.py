colour = ("Red")
flower = ("Rose")

ans = colour + " " + flower

print(ans.upper())
print(ans.lower())
print(ans)

print(type(colour))

firstname = input("What is your first name?")
lastname = input("What is your last name?")

name = firstname + " " + lastname

print("Your full name is", name)


