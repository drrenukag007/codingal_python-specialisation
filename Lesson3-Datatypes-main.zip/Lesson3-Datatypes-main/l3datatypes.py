day = ("Monday")

age = 14 

weight = 38.5

morning = True

print(type(day))
print(type(age))
print(type(weight))
print(type(morning))

print(day)
print(age)
print(weight)
print(morning)