num1 = int(input("Enter a number"))
num2 = int(input("Enter a number"))

result = num1 + num2

print(result)

print(type(num1))
print(type(num2))

