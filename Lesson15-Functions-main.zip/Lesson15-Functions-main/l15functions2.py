def myra(word1):
     for i in range (10):
          print(word1)

myra("hello")
myra("bye")


sentence = input("Enter a sentence: ")

def arym(sentence1):
     for i in range(5):
          print(sentence1)

arym(sentence)


def ryma():
     print("welcome")

ryma()