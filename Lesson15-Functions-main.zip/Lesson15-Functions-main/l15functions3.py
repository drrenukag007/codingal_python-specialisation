radius = int(input("Enter the radius of the circle: "))

def myra(radius1):
    result = 3.14*(radius**2)
    print(result)

myra(radius)


def arym(num1,num2,num3,num4):
    result = num1+num2+num3+num4
    print(result)

arym(1,2,3,4)