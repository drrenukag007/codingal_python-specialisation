def myra(num1, num2):
    result = num1 + num2
    print(result)

myra(5,6)
myra(7,8)
myra(9,10)

def arym(num1, num2, num3):
    result = num1*num2*num3
    print(result)

arym(5,6,7)