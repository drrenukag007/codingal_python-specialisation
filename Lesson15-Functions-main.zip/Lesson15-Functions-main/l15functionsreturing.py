def myra(num1, num2):
    result = num1/num2
    return result

addition = myra(7,8)
print(addition)


def arym(num1, num2):
    result = num1*num2
    return result

area = arym(6,7)
area1 = arym(7,8)
area2 = arym(8,9)
area3 = arym(9,10)
print(area)
print(area1)
print(area2)
print(area3)

