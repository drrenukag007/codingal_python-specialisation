class Circle:
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14 * self.radius * self.radius

    def perimeter(self):
        return 2 * 3.14 * self.radius


radius = float(input("Enter radius: "))
circle = Circle(radius)
print("The area of the circle is", circle.area())
print("The perimeter of the circle is", circle.perimeter())
