from tkinter import * 

window = Tk() 
window.geometry ("1000x1000") 
window.configure(bg="light blue") 

def CalculateMoney():
    amount5 = int(fivedhsnotespinbox.get())
    total5 = 5 * amount5
    amount10 = int(tendhsnotespinbox.get())
    total10 = 10 * amount10
    amount20 = int(twentydhsnotespinbox.get())
    total20 = 20 * amount20
    amount50 = int(fiftydhsnotespinbox.get())
    total50 = 50 * amount50
    amount100 = int(hundreddhsnotespinbox.get())
    total100 = 100 * amount100
    amount500 = int(fivehundreddhsnotespinbox.get())
    total500 = 500 * amount500
    amount1000 = int(thousanddhsnotespinbox.get())
    total1000 = 1000 * amount1000
    calculatemoney = total5 + total10 + total20 + total50 + total100 + total500 + total1000
    textbox.delete("1.0",END)
    textbox.insert(END, "Your total money is DHS "+str(calculatemoney))

heading = Label(window, text="Welcome to the Denomination Calculator", bg="blue", fg="light blue", font=("Arial",30)) 
heading.place(x=200,y=100)

fivedhsnote = Label(window, text="5 DHS notes: ") 
fivedhsnote.place(x=200, y=150)

fivedhsnotespinbox = Spinbox(window, values=(0,1,2,3,4,4,5,6,7,8,9,10))
fivedhsnotespinbox.place(x=200, y=180)

tendhsnote = Label(window, text="10 DHS notes: ") 
tendhsnote.place(x=200, y=220)

tendhsnotespinbox = Spinbox(window, values=(0,1,2,3,4,4,5,6,7,8,9,10))
tendhsnotespinbox.place(x=200, y=250)

twentydhsnote = Label(window, text="20 DHS notes: ") 
twentydhsnote.place(x=200, y=280)

twentydhsnotespinbox = Spinbox(window, values=(0,1,2,3,4,4,5,6,7,8,9,10))
twentydhsnotespinbox.place(x=200, y=320)

fiftydhsnote = Label(window, text="50 DHS notes: ") 
fiftydhsnote.place(x=200, y=350)

fiftydhsnotespinbox = Spinbox(window, values=(0,1,2,3,4,4,5,6,7,8,9,10))
fiftydhsnotespinbox.place(x=200, y=380)

hundreddhsnote = Label(window, text="100 DHS notes: ") 
hundreddhsnote.place(x=200, y=420)

hundreddhsnotespinbox = Spinbox(window, values=(0,1,2,3,4,4,5,6,7,8,9,10))
hundreddhsnotespinbox.place(x=200, y=450)

fivehundreddhsnote = Label(window, text="500 DHS notes: ") 
fivehundreddhsnote.place(x=200, y=480)

fivehundreddhsnotespinbox = Spinbox(window, values=(0,1,2,3,4,4,5,6,7,8,9,10))
fivehundreddhsnotespinbox.place(x=200, y=520)

thousanddhsnote = Label(window, text="1000 DHS notes: ") 
thousanddhsnote.place(x=200, y=550)

thousanddhsnotespinbox = Spinbox(window, values=(0,1,2,3,4,4,5,6,7,8,9,10))
thousanddhsnotespinbox.place(x=200, y=580)

submitbutton=Button(window,text="Calculate Total Money",bg="blue",fg="light blue", width=20, height=2,command=CalculateMoney) 
submitbutton.place(x=200,y=620)

textbox = Text(window,highlightcolor="blue",highlightthickness=10,width=40,height=3) 
textbox.place(x=200,y=680)

window.mainloop()