from tkinter import *

def Checkstrength():
    password = textbox.get()
    length = len(password)

    if length <= 5:
        resultlabel.config(text="Weak", fg="red")

    elif length <= 8:
        resultlabel.config(text="Medium", fg="yellow")

    elif length <= 12:
        resultlabel.config(text="Strong", fg="light green")

    else:
        resultlabel.config(text="Very Strong", fg="dark green")


window = Tk()
window.title("Length Converter App")
window.geometry("400x400")
window.configure(bg="light blue") 

title = Label(window, text="Password Strength Checker", bg="light yellow", fg="black", font=("Arial",16))
title.place(x=120, y=50)

bodytext = Label(window, text="Enter your password:", bg="light yellow", fg="black")
bodytext.place(x=100, y=100)

textbox = Entry(window, font=("Arial",12), width=20)
textbox.place(x=100, y=150)

checkbutton = Button(window, text="Check Strength", command=Checkstrength)
checkbutton.place(x=100, y=200)

resultlabel = Label(window, text="", bg="light yellow", fg="black", font=("Arial",14))
resultlabel.place(x=100, y=250)

window.mainloop()