from tkinter import *

window = Tk() 
window.geometry ("1000x1000") 
window.configure(bg="light blue") 
heading = Label(window, text="Welcome to the FruitShopper", bg="light yellow", fg="black", font=("Arial",30))
heading.place(x=250,y=100) 

def Calculateprice():
    fruit = fruitselectbox.get()
    quantity1 = int(quantity.get())
    totalprice = 4 * quantity1
    price.config(text="The total price is "+str(totalprice))

bodytext = Label(window, text="Select any type of fruit you want and calculate its price. Fruits range from apples, bananas, kiwi and more! ", bg="light pink", fg="black", font=("Arial",15)) 
bodytext.place(x=200, y=150)

bodytextfruit = Label(window, text="Select your desired fruit", bg="light yellow", fg="black", font=("Arial",15))
bodytextfruit.place(x=250, y=200)

fruitselectbox = Spinbox(window, values=("banana","apple","kiwi","watermelon","blueberries","strawberries","melon"))
fruitselectbox.place(x=250, y=250)

bodytextquantity = Label(window, text="Select the fruit's quantity", bg="light yellow", fg="black", font=("Arial",15))
bodytextquantity.place(x=250, y=300)

quantity = Spinbox(window, values=(1,2,3,4,5,6,7,8,9,10))
quantity.place(x=250,y=350)

pricebutton=Button(window,text="Calculate price",bg="blue",fg="light blue", width=10, height=2,command= Calculateprice) 
pricebutton.place(x=250,y=400)

price = Label(window, text="The total price is ", bg="light pink", fg="black", font=("Arial",15))
price.place(x=200, y=450)




window.mainloop() 