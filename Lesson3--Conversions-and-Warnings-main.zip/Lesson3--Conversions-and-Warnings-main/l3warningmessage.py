from tkinter import * 
from tkinter import messagebox


window = Tk() 
window.geometry ("800x800") 
window.configure(bg="light blue") 

def Warning():
    messagebox.showwarning("alert","Stop, Virus Found.")

heading = Label(window, text="Welcome to The Temperature Convert", bg="light blue", fg="black", font=("Arial",30)) 
heading.place(x=150,y=100) 

bodytext = Label(window, text="Write the celcius value") 
bodytext.place(x=200, y=200)

textbox= Entry(window, fg="black", font=("Arial",20), width = 30)
textbox.place(x=100, y=250)

button=Button(window,text="Scan for the Virus",bg="blue",fg="black", width=20, height=2,command=Warning) 
button.place(x=200,y=550)

window.mainloop() 