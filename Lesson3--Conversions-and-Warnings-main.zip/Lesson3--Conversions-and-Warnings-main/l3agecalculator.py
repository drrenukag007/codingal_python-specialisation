from tkinter import * 


window = Tk() 
window.geometry ("600x600") 
window.configure(bg="light blue") 


heading = Label(window, text="Welcome to Age Calculator", bg="light blue", fg="black", font=("Arial",20)) 
heading.place(x=200,y=100) 

bodytext = Label(window, text="Write the year you were born") 
bodytext.place(x=230, y=200)

textbox= Entry(window, fg="black", font=("Arial",20), width = 10)
textbox.place(x=200, y=250)

def Age():
    currentyear = 2026
    yearofbirth = int(textbox.get())
    currentage = currentyear-yearofbirth
    age.config(text="Your current age is "+str(currentage))

age = Label(window, text="Your current age is ", bg="light yellow", fg="black", font=("Arial",10))
age.place(x=200, y=300)

button=Button(window,text="Age Calculator",bg="blue",fg="black", width=10, height=2,command=Age) 
button.place(x=200,y=350)

window.mainloop()  