from tkinter import * 

window = Tk() 
window.geometry ("800x800") 
window.configure(bg="light blue") 

heading = Label(window, text="Welcome to The Temperature Convert", bg="blue", fg="light blue", font=("Arial",30)) 
heading.place(x=150,y=100) 

bodytext = Label(window, text="Write the celcius value") 
bodytext.place(x=200, y=200)

textbox= Entry(window, fg="black", font=("Arial",20), width = 30)
textbox.place(x=100, y=250)

def Farenheitconversion():
    celcius = int(textbox.get())
    conversion = (celcius * 1.8)+32
    conversion = round(conversion,2) 
    farenheitvalue.config(text="The farenheit value is "+str(conversion))

farenheitvalue = Label(window, text="The farenheit value is ", bg="light pink", fg="black", font=("Arial",15))
farenheitvalue.place(x=100, y=300)

farenheitbutton=Button(window,text="Convert into farenheit",bg="blue",fg="black", width=20, height=2,command=Farenheitconversion) 
farenheitbutton.place(x=200,y=350)


bodytext2 = Label(window, text="Write the farenheit value")
bodytext2.place(x=200, y=400 )

textbox2= Entry(window, fg="black", font=("Arial",20), width = 30)
textbox2.place(x=100, y=450)

def Celciusconversion():
    farenheit = float(textbox2.get())
    conversion1 = (farenheit - 32) / 1.8
    conversion1 = round(conversion1,2)
    celciusvalue.config(text="The celcius value is "+str(conversion1))

celciusvalue = Label(window, text="The celcius value is ", bg="light yellow", fg="black", font=("Arial",15))
celciusvalue.place(x=100, y=500)

celciusbutton=Button(window,text="Convert into celcius",bg="blue",fg="black", width=20, height=2,command=Celciusconversion) 
celciusbutton.place(x=200,y=550)


window.mainloop() 