age = int(input("Enter your age: "))

if (age >= 10) and (age <= 20):
    print("You are allowed to enroll into this class.")
else:
    print("You are not allowed to enroll into this class.")