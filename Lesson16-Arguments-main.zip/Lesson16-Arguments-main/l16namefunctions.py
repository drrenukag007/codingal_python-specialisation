name = input("What is your name? ")

def greet(name, message="Hi"):
    print(message,name)

greet("Good Morning", name)
greet(name)