number = int(input("Enter a number: "))

def cubefunction(number):
    result = number**3
    return result

def divisibility():
    if (number%3) == 0:
        answer = cubefunction(number)
        print("This number is divisible by 3")
        print("The cube of this number is", answer)
    else:
        print("This number is not divisible by 3")

divisibility()

