def myfunction():
    '''Hello, my name is myra Hello, my name is myraHello, my name is myraHello, my name is myraHello, my name is myraHello, my name is myraHello, my name is myraHello, my name is myraHello, my name is myra'''
    return None

print("The document contains....")
print(myfunction.__doc__)