bill = int(input("Enter your bill amount: "))
def totalbills(bill1):
    totalbill = bill+(bill*5/100)
    print(totalbill)

totalbills(bill)