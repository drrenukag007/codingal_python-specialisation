class Vehicle:
    def __init__(self, capacity):
        self.capacity = capacity

    def fare(self):
        return self.capacity * 100

class Bus(Vehicle):
    def fare(self):
        total_fare = super().fare()
        total_fare += total_fare * 0.10   
        return total_fare


bus1 = Bus(50)
print("The total bus fare is", bus1.fare())
