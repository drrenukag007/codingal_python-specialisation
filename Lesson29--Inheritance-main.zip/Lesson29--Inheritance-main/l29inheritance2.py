class Animal():
    def __init__(self,name,colour,tailtype,eyes):
        self.name=name
        self.colour=colour
        self.tailtype=tailtype
        self.eyes=eyes

    def display(self):
        print("The animal's name is", self.name)
        print("The animal's colour is", self.colour)
        print("The anima's tail type is", self.tailtype)

class Babyanimal(Animal):
    def __init__(self,name,colour,tailtype,eyes,height):
        Animal.__init__(self,name,colour,tailtype,eyes)
        self.height=height

    def play(self):
        print("The animal likes to play with other animals.")

babyanimal=Babyanimal("puppy","brown","fluffy","blue",2)
babyanimal.display()

