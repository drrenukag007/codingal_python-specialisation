#Part of object-oriented programming where the child class is able to inherit properities from the parent class.
#Parent class:
class Person():
    def __init__(self,name,age,height):
        self.name=name
        self.age=age
        self.height=height

    def display(self):
        print("The person's name is", self.name)
        print("Their age is", self.age)
        print("Their height is", self.height)

#Child class:
class Student(Person):
    def __init__(self,name,age,height,grade,fav_subject):
        Person.__init__(self,name,age,height)
        self.grade=grade
        self.fav_subject=fav_subject
    
    def play(self):
        print("The student likes to play in the park.")

    def display(self):
        Person.display(self)
        print("They study in grade", self.grade)
        print("Their favourite subject is", self.fav_subject)

class Teacher(Person):
    def __init__(self,name,age,height,subject,school):
        Person.__init__(self,name,age,height)
        self.subject=subject
        self.school=school

    def teaches(self):
        print("The teacher teaches grade 10.")

    def display(self):
        Person.display(self)
        print("The teacher teaches",self.subject)
        print("The teacher teaches at", self.school)

student1=Student("Myra",14,5.8,10,"math")
teacher=Teacher("Geeta",32,5.2,"english","DIA")

student1.display()
teacher.display()
