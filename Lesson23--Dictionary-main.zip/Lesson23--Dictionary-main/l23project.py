testdictionary = {"Codingal": 3, "is": 2, "best": 2, "for": 2, "Coding": 1}

print("Here is the test dictionary:")
print(testdictionary)

word = input("Enter the word you want to check the frequency of: ")

if word == "Codingal":
    print("The frequency of the word is", testdictionary["Codingal"])
elif word == "is":
    print("The frequency of the word is", testdictionary["is"])
elif word == "best":
    print("The frequency of the word is", testdictionary["best"])
elif word == "for":
    print("The frequency of the word is", testdictionary["for"])
elif word == "Coding":
    print("The frequency of the word is", testdictionary["Coding"])
else:
    print("That word is not in the dictionary.")
