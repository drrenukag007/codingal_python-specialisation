class Bird():
    canfly = True
    wings = 2
    layeggs = True
    legs = 2
    head = 1
    containsfeathers = True

    def sound(self):
        print("Birds can sing and chirp.")
    def fly(self):
        print("Birds like to fly with their wings.")
    def food(self):
        print("Birds use their wings to collect food.")
    
duck = Bird()
sparrow = Bird()
parrot = Bird()
woodpecker = Bird()

print(sparrow.canfly)
woodpecker.sound()
parrot.fly()
sparrow.food()
print("Sparrows have", sparrow.wings, "wings")
print("Ducks have", duck.legs, "legs")
print("Woodpeckers have", woodpecker.head, "head")
