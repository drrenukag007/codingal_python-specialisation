class Mobile():
    screensize= 4.5
    colour = "black"
    thickness = "thick"
    length =  5.89
    width = 2.81

    def communicate(self):
        print("This mobile allows you to connect with one another.")
    def watch(self):
        print("This mobile allows you to watch entertainment.")
    def pictures(self):
        print("This mobile allows you to take pictures.")

apple = Mobile()
samsung = Mobile()
andriod = Mobile()

print("The screensize of an Apple Mobile is", apple.screensize)
print(apple.colour)
print("The length of a Samsung phone is", samsung.length)
print("The width of an Andrioid phone is", andriod.width)
print(samsung.thickness)
samsung.pictures()
apple.communicate()
andriod.communicate()