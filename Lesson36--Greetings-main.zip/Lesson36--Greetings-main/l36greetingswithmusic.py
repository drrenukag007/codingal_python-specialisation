import pygame
pygame.init()
import random
import time
pygame.mixer.init()

width = 500
height = 500
screen = pygame.display.set_mode((width,height))
pygame.display.set_caption("Merry Christmas")

image1 = pygame.image.load("gaming library/christmasgreeting1.jpg")
image2 = pygame.image.load("gaming library/christmasgreeting2.jpg")
image3 = pygame.image.load("gaming library/christmasgreeting3.jpg")
image1 = pygame.transform.scale(image1,(width,height))
image2 = pygame.transform.scale(image2,(width,height)) 
image3 = pygame.transform.scale(image3,(width,height)) 
christmassong = pygame.mixer.Sound("gaming library/jinglebells.mp3") #importing the music
run = True
while run:
    screen.fill("red") 
    for i in pygame.event.get():
        if i.type == pygame.QUIT: 
            pygame.quit()

    #image1
    screen.blit(image1,(0,0))
    christmassong.play()
    pygame.display.update()
    time.sleep(2) 
    #image2
    screen.blit(image2,(0,0))
    font = pygame.font.SysFont("calibri",25)
    text = font.render("and a Happy New Year", True, "blue")
    screen.blit(text,(150,450))
    pygame.display.update()
    time.sleep(2)
    #image3
    screen.blit(image3,(0,0))
    font = pygame.font.SysFont("calibri",25)
    text = font.render("2025", True, "dark red")
    screen.blit(text,(220,15))
    pygame.display.update()
    time.sleep(2)
    