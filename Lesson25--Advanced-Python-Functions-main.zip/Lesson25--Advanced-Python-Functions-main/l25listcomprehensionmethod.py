numbers = [i for i in range(1,21)]
print(numbers)

print(    )

#even number lsit
even = [a for a in numbers if a%2==0]
print(even)

print(   )

#odd number list
odd = [m for m in numbers if m%2 != 0]
print(odd)

print(        )

#Dictionary comprehension method
num_dict = {x:x**2 for x in numbers}
print(num_dict)

print(       )

num_dict = {y:y**3 for y in numbers}
print(num_dict)

print(        )

#Map function
def square(num):
    return num * num
nums = (1,2,3,4,5,6,7,8,9,10)

result = map(square, nums)
print(list(result))
