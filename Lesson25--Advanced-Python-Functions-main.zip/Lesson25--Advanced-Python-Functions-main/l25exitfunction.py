for i in range(10):
    print(i)
    if i == 5:
        print("Exiting the program")
        exit()