name = ["Myra", "Renuka", "Ravi", "Jyoti", "Geeta"]
mood = ["happy", "excited", "thrilled", "sad", "angry"]

mapped = zip(name, mood)
print(list(mapped))


print(     )

number1 = [1,2,3,4,5,6]
number2 = [1,4,9,16,25,36]

mapped = zip(number1, number2)
print(list(mapped))