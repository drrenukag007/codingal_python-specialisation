import random

score1 = 0
score2 = 0
rounds = 0

print("Welcome to the Dice Game!")

while rounds < 10:
    dice1 = random.randint(1, 6)
    dice2 = random.randint(1, 6)

    print("Round", rounds + 1)
    print("Dice 1 rolled:", dice2)
    print("Dice 2 rolled:", dice2)

    if dice1 > dice2:
        score1 += 1
        print("Dice 1 wins this round!")
        print(   )
    elif dice2 > dice1:
        score2 += 1
        print("Dice 2 wins this round!")
        print(   )
    else:
        print("It's a tie this round!")
        print(   )

    rounds += 1

print("Final Results")
print("Dice 1 total score: ", score1)
print(   )
print("Dice 2 total score: ", score2)

if score1 > score2:
    print("Dice 1 is the winner!")
    exit()
elif score2 > score1:
    print("Dice 2 is the winner!")
    exit()
else:
    print("It's a tie overall!")
    exit()





    
