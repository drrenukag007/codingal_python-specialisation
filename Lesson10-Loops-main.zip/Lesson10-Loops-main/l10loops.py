for i in range(1,21):
    print(i)

for i in range(51,61):
    print(i)

for m in range(1,21,2):
    print(m)

for m in range(2,21,2):
    print(m)

for s in range(21,1,-1):
    print(s)
