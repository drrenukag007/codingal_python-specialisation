name = input("Enter your name: ")

for n in range(10):
    print(name)

sentence = "Hello, my name is Myra."

for i in sentence:
    print(i)