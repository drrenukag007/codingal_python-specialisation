sentence = input("Enter a sentence: ")

reversestring = " "
for i in sentence:
    reversestring = i+reversestring
print("The original sentence is", sentence, "and the reverse sentence is", reversestring)