sum = 0
for n in range(1,5):
    sum = sum+n
print(sum)

sum = 0
number = int(input("Enter a number between 1-10: "))
for n in range(1,number+1):
    sum = sum+n
print(sum)