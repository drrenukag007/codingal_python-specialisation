try:
    method = input("Would you like to use the calculator for addition, subtraction, multiplication or divison? ")
    if method == "addition": 
        num1 = int(input("Enter a number: "))
        num2 = int(input("Enter another number: "))
        result = num1+num2
        print(result)
    if method == "subtraction": 
        num1 = int(input("Enter a number: "))
        num2 = int(input("Enter another number: "))
        result = num1-num2
        print(result)
    if method == "multiplication": 
        num1 = int(input("Enter a number: "))
        num2 = int(input("Enter another number: "))
        result = num1*num2
        print(result)
    if method == "division": 
        num1 = int(input("Enter a number: "))
        num2 = int(input("Enter another number: "))
        result = num1/num2
        print(result)
except ValueError:
    print("Invalid input, enter a whole number only.")
except ZeroDivisionError:
    print("Division by 0 is not allowed, the 2nd number must be greater than 0.")
    
