try:
    age = int(input("Enter your child's age: "))
    if (age <= 0) or (age >= 18):
        raise ValueError("Age must be greater than 0 and less than 18.")
    else:
        print("Age is valid to attend school.")
except ValueError:
    print("Age is not valid to attend school.")