try:
    num1 = int(input("Enter a number: "))
    num2 = int(input("Enter another number: "))
    
    result = num1/num2
    print(result)
except ZeroDivisionError:
    print("Divison by 0 is not allowed, so do not write the 2nd number as 0.")