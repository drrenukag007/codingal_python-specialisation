try:
    num1 = int(input("Enter a number: "))
    num2 = int(input("Enter another number: "))

    result = num1+num2
    print(result)
except ValueError:
    print("Invalid input, enter a whole number only.")


try:
    num3 = float(input("Enter a number: "))
    num4 = float(input("Enter another number: "))

    result = num3+num4
    print(result)
except ValueError:
    print("Invalid input, enter decimal numbers only only.")