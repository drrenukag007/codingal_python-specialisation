import random

class Flashcards:
    def __init__(self):
        word= input("Enter the word you would like to be apart of your quiz. ")
        meaning= input("Enter the meaning of the word. ")
        self.flashcard= [] 

    def quiz(self):
        while True:
            item, meaning=random.choice(list(self.flashcard.items()))
            print("What is the meaning of ",item)
            user_answer=input("Write the meaning of the item. ")
            user_answer.append
            score=0

            if user_answer == meaning:
                print("Your answer is correct.")
                score=score+5

            else:
                print("Your answer is incorrect.")
                score=score-5

            option = int(input("Enter 0 to play again or enter 1 to exit the quiz."))

            if option:
                break

fc=Flashcards()
fc.quiz()