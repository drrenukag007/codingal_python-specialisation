import random

print("Welcome to the Fruit quiz.")

class Fruitquiz:
    def __init__(self):
        self.fruits={"apple":"red","banana":"yellow","blueberries":"blue","strawberries":"red","orange":"orange","grapes":"green","melon":"orange"}

    def quiz(self):
        while True:
            fruit,colour=random.choice(list(self.fruits.items()))
            print("What is the colour of",fruit)
            user_answer=input("Enter the colour of the fruit: ")
            score=0
            if user_answer == colour:
                print("Your answer is correct!")
                score = score+5
                print("Your score is", score)

            else:
                print("Your answer is incorrect.")
                score = score-5
                print("Your score is", score)

            option=int(input("Enter 0 to play again or enter 1 to exit."))

            if option:
                break

fq=Fruitquiz()
fq.quiz()