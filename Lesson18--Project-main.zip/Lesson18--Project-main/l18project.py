try:
    age = int(input("Enter your age: "))
    if age < 0:
        raise ValueError("Age must be greater than 0.")
    else:
        print("Your age is valid.")
        if age % 2 == 0:
            print("Your age is even.")
        else:
            print("Your age is odd.")
except ValueError:
    print("Your ag is invalid. It must be greater than 0.")