a = 10
b = 5
c = 10

if a>5 and b>3:
    print("Both these conditions are true.")
else:
    print("Both these conditions are not true.")

if a>12 and b>6:
     print("Both these conditions are true.")
else:
    print("Both these conditions are not true.")

if a>5 or b>6:
    print("Either one of these conditions are true.")
else:
    print("Both these conditions are not true.")
    