score = int(input("What is your score out of 100? "))

if score == 100 :
    print("You have scored a level 9 grade.")
elif score >= 90 and score < 100:
    print ("You have scored a level 8 grade.")
elif score >= 80 and score < 90:
    print("You have scored a level 7 grade.")
elif score >= 70 and score < 80:
    print("You have scored a level 6 grade.")
elif score >= 60 and score < 70:
    print("You have scored a level 5 grade.")
elif score >= 50 and score < 60:
    print("You have scored a level 4 grade")
elif score >= 40 and score < 50:
    print("You have scored a level 3 grade.")
elif score >= 30 and score < 40:
    print("You have scored a level 2 grade.")
elif score >= 20 and score < 30:
    print("You have scored a level 1 grade.")
elif score >=10 and score < 20:
    print("You have scored a level 1 grade.")
else:
    print("Enter a score out of 100")