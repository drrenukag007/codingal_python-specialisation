day = int(input("What day is it today? 1- Monday, 2- Tuesday, 3-Wednesday, 4-Thursday, 5-Friday, 6-Saturday, 7-Sunday "))

if day == 1:
    print("The special dish for today is pizza!")
elif day == 2:
    print("The special dish for today is pasta!")
elif day == 3:
    print("The special dish for today is cake!")
elif day == 4:
    print("The special dish for today is ice cream!")
elif day == 5:
    print("The special dish for today is bread!")
elif day == 6:
    print("The special dish for today is brownies!")
elif day == 7:
    print("The special dish for today is banana cake!")
else:
    print("Enter a valid option.")