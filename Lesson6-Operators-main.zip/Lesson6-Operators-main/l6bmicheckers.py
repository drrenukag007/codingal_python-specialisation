height = int(input("Enter your height in cm: "))
weight = int(input("Enter your weight in kg: "))

height = height / 100
bmi = weight / (height ** 2)

if bmi < 18.5:
    print("Your BMI falls under the underweight category.")
elif bmi >= 18.5 and bmi < 25:
    print("Your BMI falls under the normal category.")
elif bmi >= 25 and bmi < 30:
    print("Your BMI falls under the overweight category.")
elif bmi >= 30:
    print("Your BMI falls under the obese category.")
else:
    print("Enter a valid value.")

