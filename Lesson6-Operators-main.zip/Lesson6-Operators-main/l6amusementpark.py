height = int(input("Enter your height in cm: "))
weight = int(input("Enter your weight in kg: "))

if height >= 150 and weight <= 60:
    print("Your able to participate rides in our amusement park!")
elif height <=150 or weight >60:
    print("Unfortunately, you aren't able to participate rides in our amusement park.")

