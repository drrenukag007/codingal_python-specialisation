soap = 12
fruit = 13
milk = 14
chocolate = 15
stationary = 16

bill1 = int(input("Enter how many soaps you bought: "))
bill2 = int(input("Enter how much fruit you bought: "))
bill3 = int(input("Enter how much milk you bought: "))
bill4 = int(input("Enter how much chocolate you bought: "))
bill5 = int(input("Enter how much stationary you bought: "))

totalsoap = (bill1 * soap)
totalfruit = (bill2 * fruit)
totalmilk = (bill3 * milk)
totalchocolate = (bill4 * chocolate)
totalstationary = (bill5 * stationary)

totalbill = (totalsoap + totalfruit + totalmilk + totalchocolate + totalstationary)
print("Your total bill is",totalbill)