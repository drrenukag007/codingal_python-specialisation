num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))

if {type(num1) is int and type(num2) is int}:
    print("You have entered correct numbers")
    print(num1 * num2)
else:
    print("Enter a number only. No other datatypes are allowed.")