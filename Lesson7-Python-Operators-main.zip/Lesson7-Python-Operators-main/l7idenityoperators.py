#identity operators
num1 = 5
num2 = 6
num3 = 5

print(num1 is num2)
print(num1 is num3)
print(num1 is not num2)
print(num1 is not num3)

#membership operators
listnumbers = 1,2,3,4,5,7,8,10

print()

print(1 in listnumbers)
print(69 not in listnumbers)

#bitwise operators
gender = input("Are you a female or male? ")
age = int(input("Enter your age "))

if gender == "female" and age >=5:
    print("You are able to attend our school.")
elif gender == "male" or age >=18:
    print("You are not able to attend our school.")

