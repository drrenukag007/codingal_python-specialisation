import pygame

pygame.init()

width = 600
height = 600
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Elements")

squarewidth = 100
squareheight = 100
circleradius = 50
colour = (0, 255, 0)

squarex = (width // 2) - squarewidth - 20
squarey = (height // 2) - (squareheight // 2)

circlex = (width // 2) + circleradius + 20
circley = height // 2

run = True
while run:
    screen.fill((255, 0, 0))

    pygame.draw.rect(screen, colour,
                     (squarex, squarey, squarewidth, squareheight))
    pygame.draw.circle(screen, colour,
                       (circlex, circley), circleradius)

    for i in pygame.event.get(): 
        if i.type == pygame.QUIT: 
            pygame.quit() 

    pygame.display.update()


