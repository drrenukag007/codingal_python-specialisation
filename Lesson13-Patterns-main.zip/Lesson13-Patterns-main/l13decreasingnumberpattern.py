n = 1 
for i in range(6,1,-1):
    for j in range(2,i+1):
        print(n, end = " ")
        n = n + 1
    print()


name = "Myra"
for i in range(1,6):
    print(name*i)