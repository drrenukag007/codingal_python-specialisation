num = int(input("Enter a number: "))

odds = []
for i in range(1, num + 1):
    if i % 2 != 0:
        odds.append(i)

print("The odd numbers in this list are", odds)


fruits = ["apple", "banana", "mango"]
print([f.capitalize() for f in fruits])
