import tkinter as tk
import math

def Calculateinterest():
    principalamount = float(principalentry.get())
    timeperiod = float(timeentry.get())
    rateofinterest = float(rateentry.get())

    simpleinterest = (principalamount * timeperiod * rateofinterest) / 100
    compoundinterest = principalamount * (math.pow((1 + rateofinterest/100), timeperiod)) - principalamount

    simpleresult.config(text="Simple Interest: " + str(round(simpleinterest, 2)))
    compoundresult.config(text="Compound Interest: " + str(round(compoundinterest, 2)))


window = tk.Tk()
window.title("Age Calculator App")
window.geometry("400x400")


tk.Label(window, text="Principal Amount").pack()
principalentry = tk.Entry(window)
principalentry.pack()

tk.Label(window, text="Time (years)").pack()
timeentry = tk.Entry(window)
timeentry.pack()

tk.Label(window, text="Rate (%)").pack()
rateentry = tk.Entry(window)
rateentry.pack()

calculatebutton = tk.Button(window, text="Calculate Interest", command=Calculateinterest)
calculatebutton.pack(pady=10)

simpleresult = tk.Label(window, text="Simple Interest: ")
simpleresult.pack()

compoundresult = tk.Label(window, text="Compound Interest: ")
compoundresult.pack()

window.mainloop()