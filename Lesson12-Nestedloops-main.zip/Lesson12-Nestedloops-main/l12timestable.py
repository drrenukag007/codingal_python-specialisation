number = int(input("Enter a number between 0-15: "))

for i in range(1,11):
    print(number*i)

num1 = 5
num2 = 6
num3 = 7
num4 = 8

for i in range(1,11):
    print(num1*i)
    j = 1
    while j < 11:
        print(num2*j)
        e= 1
    while e < 11:
        print(num3*e)
        f=1
    while f < 11:
        print(num4*f)

    


