m = "How are you doing"
length=len(m)
print(length)
character = "e"
i = 0
ans = 0
while i < length:
    if m [i] == character:
        ans = (ans+1)
    i = (i + 1)
print("The total number of times the character has occured is", ans, "times")