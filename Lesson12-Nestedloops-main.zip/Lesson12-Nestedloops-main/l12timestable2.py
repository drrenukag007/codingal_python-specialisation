for m in range(5,9):
    for i in range(1,11):
        print(m*i)
    print()