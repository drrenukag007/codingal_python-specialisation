for m in range(11,16):
    for i in range(1,6):
        print(m*i)
    print()