shutdown1 = input("Do you want to switch off the system? Yes or No: ")

def shutdown(userinput):
    if userinput == "Yes":
        print("Shutting down")
    elif userinput == "No":
        print("Abort shut down")
    else:
        print("Sorry")

shutdown(shutdown1)
