from tkinter import *

window = Tk()
window.geometry("600x600")
window.configure(bg="light yellow")

heading=Label(window, text="Piano Admission Form", bg="light pink", fg="black", font=("Arial", 30))
heading.place(x=150,y=50)

bodytext1 = Label(window, text="Name", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext1.place(x=100, y=100)
textbox = Entry(window, fg="black", font=("Arial",20), width=30)
textbox.place(x=100, y=130) 

bodytext2 = Label(window, text="Age", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext2.place(x=100, y=180)
textbox2 = Entry(window, fg="black", font=("Arial",20), width=30)
textbox2.place(x=100, y=210) 

bodytext3 = Label(window, text="Gender", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext3.place(x=100, y=260)
textbox3 = Entry(window, fg="black", font=("Arial",20), width=30)
textbox3.place(x=100, y=290) 

bodytext4 = Label(window, text="Contact Number", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext4.place(x=100, y=340)
textbox4 = Entry(window, fg="black", font=("Arial",20), width=30)
textbox4.place(x=100, y=370) 

submitbutton=Button(window,text="SUBMIT",bg="blue",fg="light pink", width=10, height=2,command=window.destroy) 
submitbutton.place(x=200,y=450)

window.mainloop()


