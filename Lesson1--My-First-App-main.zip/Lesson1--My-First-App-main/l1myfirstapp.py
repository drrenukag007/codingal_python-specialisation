#basic template for the window settings:
from tkinter import * #importing tkinter library

window = Tk() #creating the window
window.geometry ("600x600") #setting the size of the window
window.configure(bg="light blue") #setting the backgorund colour of the window

heading = Label(window, text="Welcome to Fitness 8", bg="blue", fg="light blue", font=("Arial",30)) #setting the heading of the window
heading.place(x=150,y=100) #displaying the heading of the window that was set

bodytext = Label(window, text="Strength") #description text 1
bodytext.place(x=200, y=500)

textbox= Entry(window, fg="black", font=("Arial",20), width = 30) #creating textbox for users to enter text
textbox.place(x=100, y=200) #placing the textbox on the window

submitbutton=Button(window,text="SUBMIT",bg="blue",fg="light blue", width=20, height=5,command=window.destroy) #creating the submit button and issuing a command
submitbutton.place(x=200,y=400)


window.mainloop() #to make the window stay on the screen