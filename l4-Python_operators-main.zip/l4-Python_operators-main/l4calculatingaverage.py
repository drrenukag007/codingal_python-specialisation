num1 = int(input("Enter a number"))
num2 = int(input("Enter a number"))
num3 = int(input("Enter a number"))



average = (num1 + num2 + num3)/3

print(average)