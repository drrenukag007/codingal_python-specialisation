#mathematical operators
print(5+2)
print(5**2)
print(5%2)
print(5//2)

print(3+4)
print(3**4)
print(3%4)
print(3//4)

#comparision operators
print(8==8)
print(8<=8)
print(8>=8)
print(8<8)
print(8>8)

#assignment operators
num = 10
num += 10
print(num)