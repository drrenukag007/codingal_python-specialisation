marks = int(input("Enter your marks for English out of 100 "))
marks1 = int(input("Enter your marks for Math out of 100 "))
marks2 = int(input("Enter your marks for Science out of 100 "))
marks3 = int(input("Enter your marks for Computer Science out of 100 "))
marks4 = int(input("Enter your marks for History out of 100 "))

percentage = (marks + marks1 + marks2 + marks3 + marks4)/500*100

print("Your average score was",percentage)
