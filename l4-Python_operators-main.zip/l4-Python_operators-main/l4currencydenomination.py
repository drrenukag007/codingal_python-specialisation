currency = int(input("Enter the amount you want to withdraw" ))

dhs = 100 
dhs1 = 50
dhs2 = 10
denomination100 = currency//dhs 
denomination50 = currency//dhs1
denomination10 = currency//dhs2

print("The total number of 100 dhiram notes will be", denomination100)
print("The total number of 50 dhiram notes will be", denomination50)
print("The total number of 10 dhiram notes will be", denomination10)