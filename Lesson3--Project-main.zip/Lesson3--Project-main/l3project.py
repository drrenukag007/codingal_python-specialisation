from tkinter import * 

window = Tk() 
window.geometry ("800x800") 
window.configure(bg="light blue") 

heading = Label(window, text="Length Converter App", bg="light blue", fg="black", font=("Arial",30)) 
heading.place(x=150,y=100) 

bodytext = Label(window, text="Write the length in inches") 
bodytext.place(x=200, y=200)

textbox= Entry(window, fg="black", font=("Arial",20), width = 30)
textbox.place(x=100, y=250)

def Centimetersonversion():
    celcius = int(textbox.get())
    conversion = (celcius * 2.54)
    conversion = round(conversion,2) 
    centimetertvalue.config(text="The centimeter value is "+str(conversion))

centimetertvalue = Label(window, text="The centimeter value is ", bg="light pink", fg="black", font=("Arial",15))
centimetertvalue.place(x=100, y=300)

centimeterbutton=Button(window,text="Convert into centimeter",bg="blue",fg="black", width=20, height=2,command=Centimetersonversion) 
centimeterbutton.place(x=200,y=350)


bodytext2 = Label(window, text="Write the centimeters value")
bodytext2.place(x=200, y=410 )

textbox2= Entry(window, fg="black", font=("Arial",20), width = 30)
textbox2.place(x=100, y=460)

def Inchesconversion():
    centimeter = float(textbox2.get())
    conversion1 = (centimeter / 2.54)
    conversion1 = round(conversion1,2)
    inchesvalue.config(text="The length in inches value is "+str(conversion1))

inchesvalue = Label(window, text="The length in inches value is ", bg="light yellow", fg="black", font=("Arial",15))
inchesvalue.place(x=100, y=500)

inchesbutton=Button(window,text="Convert into inches",bg="blue",fg="black", width=20, height=2,command=Inchesconversion) 
inchesbutton.place(x=200,y=550)


window.mainloop() 