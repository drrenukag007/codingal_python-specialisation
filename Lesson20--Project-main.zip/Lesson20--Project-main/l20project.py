import calendar

year = int(input("Which year's calendar do you want to see: "))
currentcalendar = calendar.calendar(year)

print(currentcalendar)
