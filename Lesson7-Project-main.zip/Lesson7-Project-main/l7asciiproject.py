a = 123
b = 234
c = 345
d = 456
e = 567
f = 678
g = 789
h = 900
i = 1011
j = 1122
k = 1233
l = 1344
m = 1455
n = 1566
o = 1677
p = 1788
q = 1899
r = 2010
s = 2121
t = 2232
u = 2343
v = 2454
w = 2565
x = 2676
y = 2787
z = 2898

character = input("Enter a character: ")
if character == "a":
    print("The ASCII code of this character is", a)
elif character == "b":
    print("The ASCII code of this character is", b)
elif character == "c":
    print("The ASCII code of this character is", c)
elif character == "d":
    print("The ASCII code of this character is", d)
elif character == "e":
    print("The ASCII code of this character is", e)
elif character == "f":
    print("The ASCII code of this character is", f)
elif character == "e":
    print("The ASCII code of this character is", e)
elif character == "f":
    print("The ASCII code of this character is", f)
elif character == "g":
    print("The ASCII code of this character is", g)
elif character == "h":
    print("The ASCII code of this character is", h)
elif character == "i":
    print("The ASCII code of this character is", i)
elif character == "j":
    print("The ASCII code of this character is", j)
elif character == "k":
    print("The ASCII code of this character is", k)
elif character == "l":
    print("The ASCII code of this character is", l)
elif character == "m":
    print("The ASCII code of this character is", m)
elif character == "n":
    print("The ASCII code of this character is", n)
elif character == "o":
    print("The ASCII code of this character is", o)
elif character == "p":
    print("The ASCII code of this character is", p)
elif character == "q":
    print("The ASCII code of this character is", q)
elif character == "r":
    print("The ASCII code of this character is", r)
elif character == "s":
    print("The ASCII code of this character is", s)
elif character == "t":
    print("The ASCII code of this character is", t)
elif character == "u":
    print("The ASCII code of this character is", u)
elif character == "v":
    print("The ASCII code of this character is", v)
elif character == "w":
    print("The ASCII code of this character is", w)
elif character == "x":
    print("The ASCII code of this character is", x)
elif character == "y":
    print("The ASCII code of this character is", y)
elif character == "z":
    print("The ASCII code of this character is", z)