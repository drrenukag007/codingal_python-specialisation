piano = input("Are you done practing piano? yes or no: ")
while piano == "no":
    print("Okay, once your done close your piano")
    piano = input("Are you done practing piano? yes or no: ")
print("Okay, you can close your piano and do something else now.")