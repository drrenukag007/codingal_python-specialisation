books = input("Have you finished your book yet? yes or no: ")

while books == "no":
    print("Okay, finish your book and put it back on the shelf after.")
    books = input("Have you finished your book yet? yes or no: ")
print("Okay, put your book on the shelf and you can choose a new book!")
