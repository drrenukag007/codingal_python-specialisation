

sum = 1 
totalmultiplication = 1
while sum < 5:
    print(sum)
    totalmultiplication = totalmultiplication * sum
    sum = sum + 1
print("The total multiplication of all these numbers is", totalmultiplication)