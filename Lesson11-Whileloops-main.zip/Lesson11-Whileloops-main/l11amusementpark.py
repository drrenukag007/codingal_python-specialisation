print("Welcome to the Amusement Park! You are allowed to take unlimited rides.")

rides = input("Do you want more rides? yes or no: ")
while rides != "no":
    print("Okay then, lets take more rides.")
    rides = input("Do you want more rides? yes or no: ")

print("Okay then, lets go home.")