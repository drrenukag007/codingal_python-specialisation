bowl = input("Have you finished your food? yes or no: ")

while bowl == "no":
    print("Okay, finish your food and put it in the kitchen")
    bowl = input("Have you finished your food? yes or no: ")
print("Okay, put your food in the kitchen and then you can get a bowl of icecream!")