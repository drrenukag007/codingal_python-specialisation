num = 1 
while num < 11:
    print(num)
    num = num + 1

num = 1
while num < 21:
    print(num)
    num = num + 2

num = 2
while num < 21:
    print(num)
    num = num + 2
