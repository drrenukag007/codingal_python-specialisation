num = 1
while True:
    print(num)
    num = num + 1