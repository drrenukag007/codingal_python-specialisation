ice = input("Do you want to get icecream? Yes or no ")

if ice == "Yes":
    print("Okay, lets go to the store and get icecream!")
else:
    print("Okay, lets go home and eat food")

rain = input("Is it raining outside? Yes or no ")
if rain == "Yes":
    print("Okay, lets carry an umbrella.")
else:
    print("Okay then we don't have to carry an umbrella.")