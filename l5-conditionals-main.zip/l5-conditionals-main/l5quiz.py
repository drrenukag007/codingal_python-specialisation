print("Welcome to the quiz by Quiz Master Myra")

score= 0 
question1 = input("What is the capital of UAE? a. Delhi/b. Abu Dhabi/c. Dubai/d. Bombay ")
if question1 == "b":
    print("Great job, thats the right answer!")
    score = score + 10
    print("Your score is now", score)
else:
    print("Thats the wrong answer, try again later.")
    score = score - 5
    print("Your score is now", score)

question2 = input("What is the capital of India? a. Delhi/b. Abu Dhabi/c. Dubai/d. Bombay ")
if question2 == "a":
    print("Great job, thats the right answer!")
    score = score + 10
    print("Your score is now", score)
else:
    print("Thats the wrong answer, try again later.")
    score = score - 5
    print("Your score is now", score)

question3 = input("What colour is the sky? a. Red/b. Green/c. Blue/d. Yellow ")
if question3 == "c":
    print("Great job, thats the right answer!")
    score = score + 10
    print("Your score is now", score)
else:
    print("Thats the wrong answer, try again later.")
    score = score - 5
    print("Your score is now", score)

question4 = input("Which is the biggest river in the world? a. Amazon river/ b. River Nile/ c. River Ganga ")
if question4 == "b":
    print("Great job, thats the right answer!")
    score = score + 10
    print("Your score is now", score)
else:
    print("Thats the wrong answer, try again later.")
    score = score - 5
    print("Your score is now", score)

question5 = input("What is the colour of the sun? a.Orange/ b. Red/ c. Yellow/d. There is no sun ")
if question5 == "c":
    print("Great job, thats the right answer!")
    score = score + 10
    print("Your score is now", score)
    
else:
    print("Thats the wrong answer, try again later.")
    score = score - 5
    print("Your score is now", score)

question6 = input("What is Myra's favourite colour? a. Green/ b. Orange/ c. Red d. Blue ")
if question6 == "d":
    print("Great job, thats the right answer!")
    score = score + 10
    print("Your score is now", score)
else:
    print("Thats the wrong answer, try again later.")
    score = score - 5
    print("Your score is now", score)

question7 = input("Which answer is the tallest building in the world? a. Burj Khalifa/ b. Burj Al Arab/ c. Myra's building/ d.Arym's building ")
if question7 == "a":
    print("Great job, thats the right answer!")
    score = score + 10
    print("Your score is now", score)
else:
    print("Thats the wrong answer, try again later.")
    score = score - 5
    print("Your score is now", score)

question8 = input("What is the capital of UK? a. London/ b. Washington DC/ c. Dubai/ d. Sharjah ")
if question8 == "a":
    print("Great job, thats the right answer!")
    score = score + 10
    print("Your score is now", score)
else:
    print("Thats the wrong answer, try again later.")
    score = score - 5
    print("Your score is now", score)

question9 = input("What do animals eat? a. Food/ b. Garbage/ c. Laptops/ d.Humans ")
if question9 == "a":
    print("Great job, thats the right answer!")
    score = score + 10
    print("Your score is now", score)
else:
    print("Thats the wrong answer, try again later.")
    score = score - 5
    print("Your score is now", score)

question10 = input("What is the capital of Thailand? a. Delhi/b. Bangkok/c. Dubai/d. Bombay ")
if question1 == "b":
    print("Great job, thats the right answer!")
    score = score + 10
    print("Your score is now", score)
else:
    print("Thats the wrong answer, try again later.")
    score = score - 5
    print("Your score is now", score)


print("Your final score is", score)

