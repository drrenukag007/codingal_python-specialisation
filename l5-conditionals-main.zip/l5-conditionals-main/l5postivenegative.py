num = int(input("Enter a postive or negative number "))

if num < 0:
    print("The number is a negative number.")
else:
    print("The number is a postive number.")
