num = int(input("Enter a number between 0-99 "))

if num < 10:
    print("Its a one digit number.")
else:
    print("Its a two digit number.")
