price = int(input("What is the actual price of the item? "))
saleprice = int(input("What is the sale price of the item? "))

if price > saleprice:
    profit = price-saleprice
    print("You've lost profit by ", profit)
else:
    profit = saleprice-price
    print("You've gained profit by.", profit)