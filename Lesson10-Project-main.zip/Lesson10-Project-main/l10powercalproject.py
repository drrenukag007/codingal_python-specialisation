number = int(input("Enter a number: "))
exponent = int(input("Enter the exponent: "))

for i in range(1): 
    answer = number ** exponent
print(number, "raised to the power", exponent, "is", answer)

