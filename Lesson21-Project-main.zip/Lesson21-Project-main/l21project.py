nums = input("Enter five numbers between 1 and 4: ")

nums = [int(num) for num in nums.split(",")]

firstnumber = nums[0]
lastnumber = nums[3]

squares = [firstnumber ** 2, lastnumber ** 2]

evensquares = [num for num in squares if num % 2 == 0]
oddsquares = [num for num in squares if num % 2 != 0]

print("Squares of first and last numbers:", squares)
print("Even squares:", evensquares)
print("Odd squares:", oddsquares)

