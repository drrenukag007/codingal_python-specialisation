from tkinter import * 
from tkinter.filedialog import askopenfilename,asksaveasfilename

window = Tk() 
window.geometry ("1000x1000")
window.configure(bg="light blue")

def Openfile():
    filepath = askopenfilename(filetypes=[("textfiles","*.text")]) #when you call the function, it will open a window that will help us select only the text files. 
    textedit.delete(1.0,END) #before opening the file, it will delete the existing content written in the text editor
    with open(filepath,"r") as inputfile: #it will open the file as read only meaning you can't edit it. ("r" means read only)
        text = inputfile.read() #it will read the file and input it into the variable text.
        textedit.insert(END,text) #insert the text into the text editor- it adds from the end of the previous word
        inputfile.close()

def Savefile():
    filepath = asksaveasfilename(defaultextension="txt",filetypes=[("textfiles","*.text")]) 
    with open(filepath,"w") as outputfile: #writable file as output file
        text = textedit.get(1.0,END) #retrieve the contents from text edit
        outputfile.write(text)


heading = Label(window, text="Welcome to Text Editor", bg="blue", fg="light blue", font=("Arial",30)) 
heading.place(x=150,y=100) 

textedit = Text(window,highlightcolor="blue",highlightthickness=10) 
textedit.grid(row=2, column=2) #width and height of the text widget
textedit.place(x=150,y=200)

openbutton=Button(window,text="Open File",bg="blue",fg="black", width=20, height=2, command=Openfile) 
openbutton.place(x=150,y=600)

savebutton=Button(window,text="Save File",bg="blue",fg="black", width=20, height=2, command=Savefile) 
savebutton.place(x=150,y=650)

 
window.mainloop() 