from tkinter import *
from datetime import datetime

def calculate_age():
    year = int(textbox4.get())
    currentyear = datetime.now().year
    age = currentyear - year
    currentage.config(text="Your age is"+str(age))

window = Tk()
window.geometry("400x400")
window.configure(bg="light yellow")

heading = Label(window, text="Age Calculator App", bg="light pink", fg="black", font=("Arial", 15))
heading.place(x=150, y=20)

bodytext1 = Label(window, text="Name", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext1.place(x=100, y=50)
textbox = Entry(window, fg="black", font=("Arial", 15), width=15)
textbox.place(x=100, y=80)

bodytext2 = Label(window, text="Date", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext2.place(x=100, y=120)
textbox2 = Entry(window, fg="black", font=("Arial", 15), width=15)
textbox2.place(x=100, y=150)

bodytext3 = Label(window, text="Month", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext3.place(x=100, y=190)
textbox3 = Entry(window, fg="black", font=("Arial", 15), width=15)
textbox3.place(x=100, y=210)

bodytext4 = Label(window, text="Year", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext4.place(x=100, y=250)
textbox4 = Entry(window, fg="black", font=("Arial", 15), width=15)
textbox4.place(x=100, y=280)

currentage = Label(window, text="", bg="light pink", fg="black", font=("Arial", 15))
currentage.place(x=100, y=320)

submitbutton = Button(window, text="Calculate Age", bg="blue", fg="light pink", width=10, height=2, command=calculate_age)
submitbutton.place(x=100, y=350)

window.mainloop()
