import random
computer = random.randint(1,30)

number = 0
while number != computer:
    number = int(input("Guess the number: "))

    if number < computer:
        print("Your number is less than the computer's number.")
    elif number > computer:
        print("Your number is more than the computer's number.")
    elif number == computer:
        print("Congratulations, you have guessed the correct number!")
    else:
        print("Your guess is incorrect, try again.")
    