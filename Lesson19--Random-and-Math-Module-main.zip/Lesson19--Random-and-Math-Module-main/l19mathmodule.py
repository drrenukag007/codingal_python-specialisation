import math
print(("The square root of 64 is"),math.sqrt(64))
print(("The cube root of 64 is"),math.cbrt(64))

number = int(input("Enter a number: "))
squareroot = (math.sqrt(number))
cuberoot = (math.cbrt(number))
print(("The square root is"),squareroot)
print(("The cube root is"),cuberoot)