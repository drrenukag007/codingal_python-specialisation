#Dice
import random

dice = random.randint(1,6)
print(dice)

#Lucky Draw System
luckydraw = random.randint(1,5000)
print("The winner is", luckydraw)