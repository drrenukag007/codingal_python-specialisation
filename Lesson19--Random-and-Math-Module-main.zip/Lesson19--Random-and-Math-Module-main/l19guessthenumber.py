import random
computer = random.randint(1,10)

while number != computer:
    number = int(input("Guess the number: "))

    if number == computer:
        print("Congratulations, you have guessed the correct number.")
        break
    else:
        print("You have guessed incorrect, try again.")
