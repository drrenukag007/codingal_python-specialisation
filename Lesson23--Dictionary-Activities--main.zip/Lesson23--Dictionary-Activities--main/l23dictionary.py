groceries = {"toothbrush":3, "banana": 6, "milk": "8 ltr", "iphone": 7, "macbook": 8}

print(groceries)
print(type(groceries))

#Printing only the keys
print(groceries.keys())
print()

#Printing only the values
print(groceries.values())
print()

#Printing both keys and values
print(groceries.items())
print()

#Printing in structered format
for i, j in groceries.items():
    print(i,j)

#Adding items to the dictionary
print()
groceries["pens"] = 10
print(groceries)

groceries["teddy bear"] = 80
print(groceries)

groceries["paper"] = -50

#Deleting items from the dictionary
print()
del groceries["milk"]
print(groceries)

#Updating items from the dictionary
print()
groceries["macbook"] = 4
print(groceries)



