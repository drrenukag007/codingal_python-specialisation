a = 5
b = 10
c = 15

temp = a
a = c
c = b
b = temp

print(a)
print(b)
print(c)