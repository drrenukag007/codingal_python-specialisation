n = 1
for i in range(1, 6):
    print("  " * (5 - i), end="")
    for j in range(1, i + 1):
        print("*", end=" ")
        n += 1
    print()

print("")


n = 1
for i in range(1, 6):
    for j in range(1, i + 1):
        print("*", end=" ")
        n = n + 1
    print()

print("")


#Extra homework
for i in range(1, 6):
    print(" " * (5 - i), end="")  
    for j in range(1, i + 1):
        print("* ", end="")
    print()

for i in range(5, 0, -1):
    print(" " * (5 - i), end="")
    for j in range(1, i + 1):
        print("* ", end="")
    print()

