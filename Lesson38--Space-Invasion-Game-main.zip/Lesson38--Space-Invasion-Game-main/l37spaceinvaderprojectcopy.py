import pygame

pygame.init()
import os
from pygame.locals import *


width = 1000
height = 700
screen = pygame.display.set_mode((width,height))
pygame.display.set_caption("Space Invasion Game")
bg = pygame.transform.scale(pygame.image.load(os.path.join("gaming library/space invader project/space.png")),(width,height)) #loads the image and then scales the image according to the window's height and width. 
ship1 = pygame.image.load(os.path.join("gaming library/space invader project/ship1.png"))
ship2 = pygame.image.load(os.path.join("gaming library/space invader project/ship2.png"))
velocity = 5
bulletvelocity = 5
framepersecond = 60 #in one second 60 frames should change to make a movement effect
redship = pygame.transform.rotate(pygame.transform.scale(ship1, (60,40)),270) #scales ship1 to make it smaller
yellowship = pygame.transform.rotate(pygame.transform.scale(ship2, (60,40)),90)

def drawwindow(yellow,red,yellowbullet,redbullet):
    screen.blit(bg,(0,0))
    screen.blit(yellowship,(yellow.x, yellow.y))
    screen.blit(redship, (red.x, red.y))
    for i in redbullet:
        pygame.draw.rect(screen,"red",i)
    for i in yellowbullet:
        pygame.draw.rect(screen,"yellow",i)
    pygame.display.update()

def redshipmove(keypress,red):
    if keypress[pygame.K_LEFT]:
        red.x = red.x - 1
    if keypress[pygame.K_RIGHT]:
        red.x = red.x + 1
    if keypress[pygame.K_UP]:
        red.y = red.y - 1
    if keypress[pygame.K_DOWN]:
        red.y = red.y + 1

def yellowshipmove(keypress,yellow):
    if keypress[pygame.K_a]:
        yellow.x = yellow.x - 1
    if keypress[pygame.K_d]:
        yellow.x = yellow.x + 1
    if keypress[pygame.K_w]:
        yellow.y = yellow.y - 1
    if keypress[pygame.K_s]:
        yellow.y = yellow.y + 1


def handlebullets(yellowbullet,redbullet,yellow,red):
    for i in yellowbullet:
        i.x = i.x + bulletvelocity #ensures the direction (left-right) the bullet moves in
    for i in redbullet:
        i.x = i.x - bulletvelocity

def main():
    yellow = pygame.Rect(100,300,60,60)
    red = pygame.Rect(900,300,60,60)
    redbullet = []
    yellowbullet = []
    
    run = True 
    while run:
        for i in pygame.event.get(): 
            if i.type == pygame.QUIT: 
                pygame.quit() 
            if i.type == pygame.KEYDOWN:
                if i.key == pygame.K_RSHIFT:
                    bullet = pygame.rect(red.x + red.width, red.y + red.height// 2 - 2, 10, 5) #creating the bullet when we press the shift button
                    redbullet.append(bullet)
                if i.key == pygame.K_LSHIFT:
                    bullet = pygame.rect(yellow.x + yellow.width, yellow.y + yellow.height// 2 - 2, 10, 5)
                    yellowbullet.append(bullet)
                

        keypress = pygame.key.get_pressed() #calling the functions
        redshipmove(keypress,red)
        yellowshipmove(keypress,yellow)
        handlebullets(yellowbullet,redbullet,yellow,red)
        drawwindow(yellow,red,yellowbullet,redbullet)
    
               
main()
