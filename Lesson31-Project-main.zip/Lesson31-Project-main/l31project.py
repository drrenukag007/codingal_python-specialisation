class Bmw:
    def fuel_type(self):
        print("Most BMWs require premium unleaded gasoline with an octane rating of 91.")
    def max_speed(self):
        print("Most BMW top speeds vary significantly by model, with the electronically limited top speed for most high-performance models being 155 mph.")

class Ferrari:
    def fuel_type(self):
        print("Ferrari vehicles use high-octane, premium gasoline (petrol) as their fuel type.")
    def max_speed(self):
        print("Ferrari top speeds vary by model, with some of the fastest being the LaFerrari at 218 mph.")


u=Bmw()
i=Ferrari()

for i in (u,i):
    i.fuel_type()
    i.max_speed