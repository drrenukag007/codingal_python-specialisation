print("Today is Thursday")

print(123)
print(8+8)

print(4+5/3*4)

country = input("What country are you from? ")

print(country, "is a beautiful country!")

school = input("What are school are you in? ")

print(school, "is a wonderful school!")

name = input("What is your name?")

age= input("How old are you?")

print(name, "is", age, "years old")

