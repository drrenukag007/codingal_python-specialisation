print("Hello my name is Myra, I am 14 years old\n","I live in the United Arab Emirates")

name = input("Enter your name")
print("\nHello", name, "\nWelcome to Coding")