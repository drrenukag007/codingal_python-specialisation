from tkinter import *

def displaynumbers():
        number1 = int(textbox2.get())
        number2 = int(textbox3.get())
        number3 = number1 * number2
        returnnumber.config(text="The product of these two numbers is "+str(number3),  bg="light pink", fg="light yellow", font=("Arial", 10))

window = Tk()
window.geometry("300x400")
window.configure(bg="light yellow")

heading = Label(window, text="Getting Started with Widgets", bg="light pink", fg="black", font=("Arial", 15))
heading.place(x=30, y=50)

bodytext1 = Label(window, text="Input two numbers and the app will return them to you.", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext1.place(x=30, y=100)

bodytext2 = Label(window, text="Number 1", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext2.place(x=30, y=150)
textbox2 = Entry(window, fg="black", font=("Arial", 15), width=15)
textbox2.place(x=30, y=190)

bodytext3 = Label(window, text="Number 2", bg="light pink", fg="light yellow", font=("Arial", 10))
bodytext3.place(x=30, y=240)
textbox3 = Entry(window, fg="black", font=("Arial", 15), width=15)
textbox3.place(x=30, y=280)

returnnumber = Label(window, text="", bg="light pink", fg="black", font=("Arial", 15))
returnnumber.place(x=30, y=320)

submitbutton = Button(window, text="Calculate", bg="blue", fg="light pink", width=10, height=2, command=displaynumbers)
submitbutton.place(x=30, y=350)

window.mainloop()