class Animal():
    def move(self):
        print("Different types of animals move in different ways.")
    
class Cat(Animal):
    def move(self):
        print("I can walk and climb trees.")

class Lion(Animal):
    def move(self):
        print("I can walk slowly but I cannot climb.")

class Human(Animal):
    def move(self):
        print("I can walk, run, jump, and climb.")

c= Cat()
print("The object of cat class is")
c.move()

l= Lion()
print("The object of lion class is")
l.move()

h= Human()
print("The object of human class is")
h.move()