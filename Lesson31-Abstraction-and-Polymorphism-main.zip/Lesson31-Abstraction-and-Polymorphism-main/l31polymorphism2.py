class UAE:
    def Nationallanguage(self):
        print("The national language in the UAE is Arabic")

class India:
    def Nationallanguage(self):
        print("The national language in India is Hindi.")

class Spain:
    def Nationallanguage(self):
        print("The national language in Spain is Spanish.")

class France:
    def Nationallanguage(self):
        print("The national language in France is French.")

u=UAE()
i=India()
s=Spain()
f=France()

for i in (u,i,s,f):
    i.Nationallanguage()