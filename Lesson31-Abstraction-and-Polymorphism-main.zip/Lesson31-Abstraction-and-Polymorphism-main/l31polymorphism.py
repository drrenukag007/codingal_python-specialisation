class Square:
    def __init__(self,side):
        self.side=side
    def area(self):
            print("The area of a square is",self.side*self.side)

class Circle:
    def __init__(self,radius):
        self.radius=radius
    def area(self):
        print("The area of a circle is",3.14*self.radius*self.radius)

sq= Square(8)
cr= Circle(8)

for i in (cr,sq):
    i.area()
