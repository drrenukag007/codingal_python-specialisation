class Library():
    def read(self):
        print("The library has many books for you to read.")

class Mystery(Library):
    def read(self):
        print("Many people read mystery books in the library.")

class Dystopian(Library):
    def read(self):
        print("Many people read dystopian books in the library.")

class Nonfiction(Library):
    def read(self):
        print("Many people read non-fiction books in the library.")

m=Mystery()
m.read()
print("The objective of mystery class is")
d=Dystopian()
d.read()
print("The objective of the dystopian class is")
n=Nonfiction()
n.read()
print("The objective of the non-fiction class is")
    