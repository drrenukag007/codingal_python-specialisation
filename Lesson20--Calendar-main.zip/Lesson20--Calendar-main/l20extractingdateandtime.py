import datetime

current = datetime.datetime.now()
print(current)
print("Today's date is",current.day)
print("Today's month is", current.month)
print("Today's year is", current.year)
print("The current hour is", current.hour)
print("The current minute is", current.minute)
print("The current second is", current.second)

print("       ")

calendar = input("What do you want to know from the calendar? The date, month, year or time? ")
if calendar == "date":
    print("Today's date is",current.day)
elif calendar == "month":
    print("Today's month is", current.month)
elif calendar == "year":
    print("Today's year is", current.year)
elif calendar == "time":
    print("The current hour is", current.hour, "and the current minute is", current.minute)
else:
    print("Invalid input, enter an input mentioned in the qustion.")



