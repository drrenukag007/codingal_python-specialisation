import calendar

year = 2025
currentcalendar = calendar.calendar(year)

print(currentcalendar)