import calendar

calendarmonth = input("Do you want to see the entire month's calendar? yes or no: ")

if calendarmonth == "yes":
    month = int(input("Which month's calendar do you want to see: "))
    year = int(input("Which year do you want to see? "))
    print(calendar.month(year,month))
elif calendarmonth == "no":
    years = int(input("Which year's calendar do you want to see: "))
    currentcalendar = calendar.calendar(years)

    print(currentcalendar)
else:
    print("Invalid input, choose the right option (yes or no)")