#items
items = ["book", "laptop", "phone", "water bottle", "pen", "paper", "candle", "pencil"]

print(items)
print()

#countring items
print(len(items))

#adding items to a list
items.append("keychain")
items.append("photo")

print(items)
print()


#deleting items from a list- "pop" only deletes the last item from the list
items.pop()
items.pop()

print(items)
print()

#indexing- picking out only one item from the list
print(items[0])
print(items[7])
print()


#indexing-deleting certain items from the list
items.pop(7)
print(items)
print()


#changing/updating items
items[1]= "watermelon"
print(items)

items[4]= "pencil"
print(items)

print()
#format structuring
for i in items:
    print(i)

print()
count = 0
while count <7:
    print(items[count])
    count= count+1
