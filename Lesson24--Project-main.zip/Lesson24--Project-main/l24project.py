Set1 = {1, 2, 3, 4, 5}
Set2 = {1, 5, 6, 7, 8, 9}

print("Set 1:", Set1)
print("Set 2:", Set2)
print("The symmetric difference is", Set1.symmetric_difference(Set2))