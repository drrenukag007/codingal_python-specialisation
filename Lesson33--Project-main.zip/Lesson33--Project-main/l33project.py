import pygame

pygame.init()

width = 500
height = 500
screen = pygame.display.set_mode((width,height))
pygame.display.set_caption("My first game screen")
character = pygame.image.load("gaming library/donaldduck.png")

donaldduckx = -100
donaldducky = -100


run = True 
while run:
    screen.fill("grey") 
    screen.blit(character, (donaldduckx, donaldducky))
    for i in pygame.event.get(): 
        if i.type == pygame.QUIT: 
            pygame.quit()
    pygame.display.update()
