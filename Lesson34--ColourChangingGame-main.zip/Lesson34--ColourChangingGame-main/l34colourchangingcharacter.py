import pygame
from pygame.locals import *

pygame.init()

width = 800
height = 800
screen = pygame.display.set_mode((width,height))
pygame.display.set_caption("Spongebob")

character = pygame.image.load("gaming library/spongebob.png")
character2 = pygame.image.load("gaming library/mrbean.png")


#coordinates of the square
spongebobx = 30
spongeboby = 30
mrbeanx = 200
mrbeany = 200

run = True 
while run:
    screen.fill("blue") 
    screen.blit(character, (spongebobx, spongeboby))
    screen.blit(character2, (mrbeanx, mrbeany))


    for i in pygame.event.get():
        if i.type == pygame.QUIT: 
            pygame.quit()
        if i.type == pygame.KEYDOWN:
            if i.key == K_LEFT:
                spongebobx = spongebobx - 10
                mrbeanx = mrbeanx + 10
            if i.key == K_RIGHT:
                spongebobx = spongebobx + 10
                mrbeanx = mrbeanx - 10
            if i.key == K_UP:
                spongeboby = spongeboby - 10
                mrbeany = mrbeany + 10
            if i.key == K_DOWN:
                spongeboby = spongeboby + 10
                mrbeany = mrbeany - 10

        
    pygame.display.update()
pygame.quit()