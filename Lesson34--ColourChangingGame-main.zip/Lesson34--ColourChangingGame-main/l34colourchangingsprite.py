import pygame

pygame.init()

width = 600
height = 600
screen = pygame.display.set_mode((width,height))
pygame.display.set_caption("Colour Changing Sprite")

squarewidth = 60
squareheight = 60
currentcolour = "green"

#coordinates of the square
squarex = 30
squarey = 30

run = True 
while run:
    screen.fill("red") 
    #taking the coordinates, width and height to draw the square
    pygame.draw.rect(screen,currentcolour,(squarex, squarey, squarewidth, squareheight))
    for i in pygame.event.get():
        if i.type == pygame.QUIT: 
            pygame.quit()
        press = pygame.key.get_pressed() #tracks which key on the keyboard was pressed
        if press[pygame.K_LEFT]: #if user presses left arrow key
            squarex = squarex - 20
            currentcolour = "yellow"
        elif press[pygame.K_RIGHT]: #if user presses right arrow key
            squarex = squarex + 20
            currentcolour = "blue"
        elif press[pygame.K_UP]: #if user presses up arrow key
            squarey = squarey - 20
            currentcolour = "pink"
        elif press[pygame.K_DOWN]: #if user presses down arrow key
            squarey = squarey + 20
            currentcolour = "orange"
        else:
            currentcolour = "green"


    pygame.display.update()
pygame.quit()