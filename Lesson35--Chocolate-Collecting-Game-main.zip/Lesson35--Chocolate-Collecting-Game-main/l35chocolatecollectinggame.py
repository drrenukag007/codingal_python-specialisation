import pygame
from pygame.locals import *
import random


pygame.init()

width = 500
height = 500
screen = pygame.display.set_mode((width,height))
pygame.display.set_caption("Rocket Collecting Game")
rocket1 = pygame.image.load("gaming library/rocket.png")
chocolate2 = pygame.image.load("gaming library/chocolate.png")
score = 0
rocket1 = pygame.transform.scale(rocket1,(200,200)) #resizing the picture
chocolate2 = pygame.transform.scale(chocolate2,(50,50))
rocketx = 150
rockety = 100
chocolatex = 40
chocolatey = 60


run = True 
while run:
    rocketrect = pygame.Rect(rocketx, rockety, 100, 100) #rect makes an internal invisible rectangle around the image 
    chocolaterect = pygame.Rect(chocolatex, chocolatey, 50, 50 )
    screen.fill("blue")
    screen.blit(rocket1, (rocketx, rockety))
    screen.blit(chocolate2,(chocolatex, chocolatey))
    print("score: ", score)

    if rocketrect.colliderect(chocolaterect): #changing the position of the chocolate when the rocket touches it
        chocolatex = random.randint(100,400)
        chocolatey = random.randint(100,400)
        score = score+1

    for i in pygame.event.get(): 
        if i.type == pygame.QUIT: 
            pygame.quit() 
        if i.type == pygame.KEYDOWN:
            if i.key == K_LEFT:
                rocketx = rocketx - 20
            if i.key == K_RIGHT:
                rocketx = rocketx + 20
            if i.key == K_UP:
                rockety = rockety - 20
            if i.key == K_DOWN:
                rockety = rockety + 20


    pygame.display.update()

