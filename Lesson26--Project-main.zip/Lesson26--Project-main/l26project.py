import random
import string

lower = string.ascii_lowercase
upper = string.ascii_uppercase
digits = string.digits

allcharacters = lower + upper + digits
password = ''.join(random.choice(allcharacters) for i in range(8))  

print(password)

