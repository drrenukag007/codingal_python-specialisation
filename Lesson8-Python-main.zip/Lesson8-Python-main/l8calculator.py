num1 = int(input("Enter a number: "))
num2 = int(input("Enter a number: "))

calculation = input("Do you want to a. add, b. subtract, c.multiply, d. divide? ")

if calculation == "a":
    answer = (num1+num2)
    print(num1, "plus", num2, "is", answer)
elif calculation == "b":
    answer = (num1-num2)
    print(num1, "minus", num2, "is", answer)
elif calculation == "c":
    answer = (num1*num2)
    print(num1, "multiplied by", num2, "is", answer)
elif calculation == "d":
    answer = (num1/num2)
    print(num1, "divided by", num2, "is", answer)
    


