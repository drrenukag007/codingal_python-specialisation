num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))

divisibility= num1%num2

if divisibility == 0:
    print(num1, "is divisible by", num2)
else:
    print(num1, "is not divisible by", num2)