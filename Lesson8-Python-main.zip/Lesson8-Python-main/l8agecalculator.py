birthyear = int(input("Which year were you born?"))

age = 2025-birthyear
print("Your age is", age)