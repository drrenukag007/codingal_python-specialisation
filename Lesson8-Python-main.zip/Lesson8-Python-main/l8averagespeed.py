speed1 = 10
speed2 = 20
speed3 = 30

average= (speed1+speed2+speed3)/3
print("The average speed of all the cyclists is", average)

if speed1 < average:
    print("The first cyclist has the slowest speed.")
elif speed2 < average:
    print("The second cyclist has the slowest speed.")
elif speed3 < average:
    print("The third cyclist has the slowest speed.")