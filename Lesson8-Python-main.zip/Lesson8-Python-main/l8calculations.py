a = 10
b = 8
c = 6
d = 4

equation = (a+b+d)/(d*c)+(b-c)
print(equation)