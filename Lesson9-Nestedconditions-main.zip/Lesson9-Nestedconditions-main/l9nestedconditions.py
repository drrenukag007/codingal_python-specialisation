a = 13
if a>10:
    print("a is bigger than 10")
elif a>12:
    print("a is greater than 12")
elif a>=10:
    print("a is smaller than 12 and 15")
else:
    print("a is smaller than 10")

