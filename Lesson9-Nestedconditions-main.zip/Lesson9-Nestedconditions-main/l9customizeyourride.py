
#Write a program to select a ride

#according to your preference. The ride

#is divided into two major categories: 1.

#Bike 2. Car And further, bikes and cars

#are divided into 2 subcategories. To

#give the user better selection options.

ride = input("Would you want to ride in a bike or a car? ")

if ride == "bike":
    bike = input("Which type of bike would you like to ride- a scotter, a regular bike, a motorcycle? ")
    if bike == "a scotter":
        print("You have selected a scotter as your ride.")
    elif bike == "a regular bike":
        print("You have selected a regular bike as your ride.")
    elif bike == "a motorcycle":
        print("You have selected a motorcycle as your ride.")
elif ride == "car":
    car = input("Which type of bike would you like to ride- a small car, a regular car, a big car? ")
    if car == "a small car":
        print("You have selected a small car as your ride.")
    elif car == "a regular car":
        print("You have selected a regular car as your ride.")
    elif car == "a big car":
        print("You have selected a big car as your ride.")

