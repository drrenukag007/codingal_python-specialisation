#Suppose the user is consuming less than 50 units. The per unit cost will be 2.60, and the tax on that bill will be 25. If a user is consuming more than 50 but less than
#100. Then the per-unit cost will be 3.25,
#and the tax on that bill will be 35 If the
#user is coming more than 100 and less
#than 200. Then the per-unit cost will be
#5.26, and the tax will be 45 And above
#200, the cost of the unit is 8.45, and the tax is 75.



units = int(input("How many units of electricity have you consumed? "))

if units < 50:
    bill = (units*2.60)+25
    print("Your total bill is", bill)
elif (units > 50) and (units < 100):
    bill = (units*3.25)+35
    print("Your total bill is", bill)
elif (units > 100) and (units < 200):
    bill = (units*5.26)+45
    print("Your total bill is", bill)
elif units > 200:
    bill = (units*8.45)+75
    print("Your total bill is", bill)








