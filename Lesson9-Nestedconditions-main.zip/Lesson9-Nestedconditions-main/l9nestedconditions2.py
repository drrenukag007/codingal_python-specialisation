id = input("Are you carrying your student ID? ")

if id == "yes":
    medical = input("Do you have any medical issues? ")
    if medical == "no":
        print("You are permitted to enter the exam hall.")
    else:
        print("You are not permitted to enter the exam hall.")
else:
    print("You are not permitted to enter the exam hall.")