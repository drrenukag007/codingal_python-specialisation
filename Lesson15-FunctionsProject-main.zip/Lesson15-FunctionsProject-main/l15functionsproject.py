radius = int(input("Enter the radius of the circle: "))

def myra(radius1):
    result = 2 * 3.14 * radius1 
    print("The circumference of the circle is", result)

myra(radius)
