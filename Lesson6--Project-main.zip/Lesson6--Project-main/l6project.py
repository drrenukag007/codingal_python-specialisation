from tkinter import *
import random

def Play():
    userchoice = choice.get()
    options = ["Rock", "Paper", "Scissors"]
    computerchoice = random.choice(options)

    computerlabel.config(text="Computer chose: " + computerchoice)

    if userchoice == computerchoice:
        resultlabel.config(text="It's a Tie!")

    elif (userchoice == "Rock" and computerchoice == "Scissors") or \
         (userchoice == "Paper" and computerchoice == "Rock") or \
         (userchoice == "Scissors" and computerchoice == "Paper"):
        resultlabel.config(text="You Win!")

    else:
        resultlabel.config(text="Computer Wins!")


window = Tk()
window.title("Length Converter App")
window.geometry("400x400")
window.configure(bg="light blue") 

title = Label(window, text="Rock Paper Scissors Game", font=("Arial",16), bg="light pink", fg="black")
title.place(x=110, y=50)

instruction = Label(window, text="Choose Rock, Paper, or Scissors", bg="light yellow", fg="black")
instruction.place(x=110, y=100)

choice = StringVar()

rock = Radiobutton(window, text="Rock", variable=choice, value="Rock", bg="light yellow", fg="black")
paper = Radiobutton(window, text="Paper", variable=choice, value="Paper", bg="light yellow", fg="black")
scissors = Radiobutton(window, text="Scissors", variable=choice, value="Scissors", bg="light yellow", fg="black")

rock.place(x=170, y=140)
paper.place(x=170, y=170)
scissors.place(x=170, y=200)

playbutton = Button(window, text="Play", command=Play)
playbutton.place(x=180, y=230)

computerlabel = Label(window, text="", bg="light pink", fg="black")
computerlabel.place(x=130, y=270)

resultlabel = Label(window, text="", font=("Arial",14), bg="light pink", fg="black")
resultlabel.place(x=150, y=310)

window.mainloop()