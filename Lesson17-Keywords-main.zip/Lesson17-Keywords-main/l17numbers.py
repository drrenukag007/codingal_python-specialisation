for i in range(10,0,-1):
    if i == 5:
        pass
    print(i)
num = 10
while num > 0:
    num = num-1
    if num == 5:
        continue
    print(num)
print("end")
    
    