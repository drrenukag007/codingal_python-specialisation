sentence = input("Enter a sentence: ")

for i in sentence:
    if i == "A":
        print("A is present in the sentence.")
        break
    else:
        print("A is not present in the sentece.")


#Write a program to satisfy the following conditions of the given

#range: If the number is divisible by 20, it provides an output "twist."

#If the number is divisible by 15, it will pass (no output) If the number

#is divisible by 5, it will give an output “fizz.” If the number is divisible

#by 3, it will give an output "buzz." Otherwise, it will give the output

#of that number.

number = int(input("Enter a number: "))

answer = number%20
answer2 = number%15
answer3 = number%5
answer4 = number%3

for i in range(10):
    if answer == 0:
        print("twist.")
        continue
    if answer2 == 0:
        pass
    if answer3 == 0:
        print("fizz.")
    if answer4 == 0:
        print("buzz")
    else:
        print(number/3)