#Return
def myfunction(num1,num2):
    return(num1+num2)

total=myfunction(3,5)
print(total)

print("          ")

#Continue
for i in range(1,21):
    print(i)
    if i == 5:
        print("We have reached level1")
        continue

print("        ")

#Break
for j in range(1,21):
    print(j)
    if j == 5:
        print("We have reached level1")
        break
#Pass
a = 10
b = 20
if a < b:
    pass
else:
    print("b is less than a.")

