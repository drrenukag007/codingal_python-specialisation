tup1 = (4,3,2,2,-1,18)
tup2 = (2,4,8,8,3,2,9)

def product(tuple):
    product = 1
    for number in tuple:
        product *= number
    return product

product1 = product(tup1)
product2 = product(tup2)

print("The product of tup1 is", product1)
print("The product of tup2 is", product2)