sunny = 0
raining = 0

week_weather = (1,2,2,1,2,1,1)

for day in week_weather:
    if day == 1:
        sunny += 1
    elif day == 2:
        raining += 1

print("In this week, the sunny days were:", sunny)
print("In this week, the raining days were:", raining)
