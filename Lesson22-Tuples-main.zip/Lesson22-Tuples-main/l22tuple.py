personal_data = ("Myra", "2nd March", "India", "female")

print(personal_data)
print(type(personal_data))

print(len(personal_data))
print(personal_data[0])
print(personal_data[3])

#slicing- extracting certain numbers of items
print(personal_data[0:3])
print(personal_data[1:3])

for i in personal_data:
    print(i)

