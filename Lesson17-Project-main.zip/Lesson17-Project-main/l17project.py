paid = 4.00
bill = 2.50

def change(paid, bill):
    return paid - bill   

change1 = change(paid, bill)

print("The shopkeeper should return $", change1)
