import pygame
import os
from pygame.locals import *
pygame.mixer.init()


pygame.init()

width = 1000
height = 700
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Space Invasion Game")
bg = pygame.transform.scale(pygame.image.load(os.path.join("gaming library/space invader project/space.png")), (width, height))
ship1 = pygame.image.load(os.path.join("gaming library/space invader project/ship1.png"))
ship2 = pygame.image.load(os.path.join("gaming library/space invader project/ship2.png"))
sound = pygame.mixer.Sound(os.path.join("gaming library/space invader project/space-438391.mp3")) 
bulletvelocity = 5
RED_HIT = pygame.USEREVENT
YELLOW_HIT = pygame.USEREVENT
framepersecond = 60 #in one second 60 frames should change to make a movement effect
redship = pygame.transform.rotate(pygame.transform.scale(ship1, (60, 40)), 270) #scales ship1 to make it smaller
yellowship = pygame.transform.rotate(pygame.transform.scale(ship2, (60, 40)), 90)

red_score = 0
yellow_score = 0
font = pygame.font.Font('freesansbold.ttf', 32)
textX = 10
textY = 10

def drawwindow(yellow, red, yellowbullet, redbullet):
    screen.blit(bg, (0, 0))
    screen.blit(yellowship, (yellow.x, yellow.y))
    screen.blit(redship, (red.x, red.y))

    for i in redbullet:
        pygame.draw.rect(screen, "red", i)
    for i in yellowbullet:
        pygame.draw.rect(screen, "yellow", i)

    show_score(textX, textY) 
    pygame.display.update()

def show_score(x, y):
    score_text = f"Red Score: {red_score}  Yellow Score: {yellow_score}"
    score = font.render(score_text, True, (255, 255, 255))
    screen.blit(score, (x, y))

def redshipmove(keypress, red):
    if keypress[pygame.K_LEFT]:
        red.x -= 1
    if keypress[pygame.K_RIGHT]:
        red.x += 1
    if keypress[pygame.K_UP]:
        red.y -= 1
    if keypress[pygame.K_DOWN]:
        red.y += 1

def yellowshipmove(keypress, yellow):
    if keypress[pygame.K_a]:
        yellow.x -= 1
    if keypress[pygame.K_d]:
        yellow.x += 1
    if keypress[pygame.K_w]:
        yellow.y -= 1
    if keypress[pygame.K_s]:
        yellow.y += 1

def handlebullets(yellowbullet, redbullet, yellow, red):
    global red_score, yellow_score  
    
    for i in yellowbullet:
        i.x += bulletvelocity
        if red.colliderect(i):  
            pygame.event.post(pygame.event.Event(RED_HIT))
            yellow_score += 1  
            yellowbullet.remove(i)  
            break 
    for i in redbullet:
        i.x -= bulletvelocity
        if yellow.colliderect(i):  
            pygame.event.post(pygame.event.Event(YELLOW_HIT))
            red_score += 1  
            redbullet.remove(i)  
            break  

def main():
    yellow = pygame.Rect(100, 300, 60, 60)
    red = pygame.Rect(900, 300, 60, 60)
    redbullet = []
    yellowbullet = []
    redhealth = 10
    yellowhealth = 10
    sound.play()

    
    run = True 
    while run:
        for event in pygame.event.get(): 
            if event.type == pygame.QUIT: 
                run = False 
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RSHIFT:
                    bullet = pygame.Rect(red.x + red.width, red.y + red.height // 2 - 2, 10, 5)
                    redbullet.append(bullet)
                if event.key == pygame.K_LSHIFT:
                    bullet = pygame.Rect(yellow.x + yellow.width, yellow.y + yellow.height // 2 - 2, 10, 5)
                    yellowbullet.append(bullet)
            if event.type == RED_HIT:
                redhealth -= 1
            if event.type == YELLOW_HIT:
                yellowhealth -= 1

        keypress = pygame.key.get_pressed()
        redshipmove(keypress, red)
        yellowshipmove(keypress, yellow)
        handlebullets(yellowbullet, redbullet, yellow, red)
        drawwindow(yellow, red, yellowbullet, redbullet)


    pygame.quit()

main()