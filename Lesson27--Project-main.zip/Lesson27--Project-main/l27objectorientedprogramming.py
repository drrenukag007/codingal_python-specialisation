class Dog():
    canfly = False
    legs = 4
    head = 1
    ears = 2
    tail = 1
    
    def bark(self):
        print("woof-woof")

    def play(self):
        print("The dog likes to play in the park")

golden_retriever = Dog()
pomeranian = Dog()
husky = Dog()

print(golden_retriever.legs)
print(golden_retriever.canfly)
print(golden_retriever.head)
print(golden_retriever.ears)
print("Husky has", husky.tail, "tail")

pomeranian.bark()
husky.play()






